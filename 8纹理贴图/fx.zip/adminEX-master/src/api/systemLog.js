import request from '@/utils/request';

export default function queryLog(params) {
  return request({
    url: '/sys/selectLogList',
    method: 'post',
    data: { params },
  });
}
