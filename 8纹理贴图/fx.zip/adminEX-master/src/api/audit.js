import request from '@/utils/request';

// 资料审核列表
export default async function queryList(params) {
  return request({
    url: '/client/selectNotExamineDocList',
    method: 'post',
    data: { params },
  });
}
