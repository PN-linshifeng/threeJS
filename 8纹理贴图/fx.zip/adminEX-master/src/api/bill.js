import request from '@/utils/request';

export async function getDeposit(params) {
  return request({
    url: '/api/pay/depositPage',
    method: 'get',
    params,
  });
}

export async function deposit(params) {
  return request({
    url: '/api/pay/deposit',
    method: 'post',
    data: { params },
  });
}
