import request from '@/utils/request';

export async function queryList(params) {
  return request({
    url: '/campaign/selectADLandPage',
    method: 'post',
    data: { params },
  });
}

export async function addADLandPage(params) {
  return request({
    url: '/campaign/addADLandPage',
    method: 'post',
    data: { params },
  });
}
