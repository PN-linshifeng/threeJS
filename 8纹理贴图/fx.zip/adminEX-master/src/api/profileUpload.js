import request from '@/utils/request';

// 提交资料
export async function addUserDoc(params) {
  return request({
    url: '/upload/addUserDoc',
    method: 'post',
    data: { params },
  });
}

// 提交资料
export async function querytDocList(params) {
  return request({
    url: '/client/selectDocList',
    method: 'post',
    data: { params },
  });
}
