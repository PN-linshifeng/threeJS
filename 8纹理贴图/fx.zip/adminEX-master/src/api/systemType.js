import request from '@/utils/request';

// 获取类型列表
export async function queryList(params) {
  return request({
    url: '/sys/selectTypeList',
    method: 'post',
    data: { params },
  });
}

// 添加类型
export async function addType(params) {
  return request({
    url: '/sys/addTypeRD',
    method: 'post',
    data: { params },
  });
}

// 更新类型
export async function updateType(params) {
  return request({
    url: '/sys/updateType',
    method: 'post',
    data: { params },
  });
}

// 删除类型
export async function deleteType(params) {
  return request({
    url: '/sys/deleteType',
    method: 'get',
    params,
  });
}

// 客户类型列表【账户类型。文档类别等等】
export async function clientDoc(params) {
  return request({
    url: '/client/selectClientDoc',
    method: 'get',
    params,
  });
}

// 文档类型列表
export async function docType(params) {
  return request({
    url: '/sys/selectDocType',
    method: 'get',
    params,
  });
}
