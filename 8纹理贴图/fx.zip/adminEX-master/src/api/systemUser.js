import request from '@/utils/request';

// 获取用户列表
export async function selectUserByParent(params) {
  return request({
    url: '/user/selectUserByParent',
    method: 'post',
    data: { params },
  });
}

// 添加用户
export async function addUser(params) {
  return request({
    url: '/user/addUser',
    method: 'post',
    data: { params },
  });
}

// 更新用户
export async function updateUser(params) {
  return request({
    url: '/user/updateUser',
    method: 'post',
    data: { params },
  });
}

// 删除用户
export async function deleteUser(params) {
  return request({
    url: '/user/deleteUser',
    method: 'post',
    data: { params },
  });
}
