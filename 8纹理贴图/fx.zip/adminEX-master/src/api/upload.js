const uploadDocFile = '/api/upload/uploadDocFile';
export default uploadDocFile;
