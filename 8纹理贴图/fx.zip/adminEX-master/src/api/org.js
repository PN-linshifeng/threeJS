import request from '@/utils/request';

export default async function queryList(params) {
  return request({
    url: '/org/selectOrganList',
    method: 'get',
    params,
  });
}

export async function addOrg(params) {
  return request({
    url: '/org/addOrg',
    method: 'post',
    data: { params },
  });
}

export async function updateOrg(params) {
  return request({
    url: '/org/updateOrg',
    method: 'post',
    data: { params },
  });
}

export async function deleteOrg(params) {
  return request({
    url: '/org/deleteOrg',
    method: 'get',
    params,
  });
}
