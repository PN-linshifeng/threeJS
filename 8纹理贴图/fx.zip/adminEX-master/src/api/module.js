import request from '@/utils/request';

export async function queryList(params) {
  return request({
    url: '/module/selectModuleList',
    method: 'get',
    params,
  });
}

// 更新功能
export async function updateModule(params) {
  return request({
    url: '/module/updateModule',
    method: 'post',
    data: { params },
  });
}

// 新增功能
export async function addModule(params) {
  return request({
    url: '/module/addModule',
    method: 'post',
    data: { params },
  });
}

// 删除功能
export async function deleteModule(params) {
  return request({
    url: '/module/deleteModule',
    method: 'get',
    params,
  });
}
