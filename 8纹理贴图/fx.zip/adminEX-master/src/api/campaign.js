import request from '@/utils/request';

export async function queryList(params) {
  return request({
    url: '/campaign/selectMasterCampaign',
    method: 'post',
    data: { params },
  });
}

export async function addCampaign(params) {
  return request({
    url: '/campaign/selectMasterCampaign',
    method: 'post',
    data: { params },
  });
}
