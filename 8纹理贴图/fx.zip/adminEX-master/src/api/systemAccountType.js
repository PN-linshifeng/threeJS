import request from '@/utils/request';

// 获取账户类型列表
export async function queryList(params) {
  return request({
    url: '/sys/selectAffiliateGroup',
    method: 'post',
    data: { params },
  });
}

// 添加账户类型
export async function addAffiliateGroup(params) {
  return request({
    url: '/sys/insertAffiliateGroup',
    method: 'post',
    data: { params },
  });
}

// 添加账户类型  废弃
export async function addGroupWeb(params) {
  return request({
    url: '/sys/insertGroupWeb',
    method: 'post',
    data: { params },
  });
}

// MT4组列表
export async function queryMt4Group(params) {
  return request({
    url: '/mt4/selectMTGroup',
    method: 'post',
    data: { params },
  });
}

// 佣金编码列表
export async function queryAffiliateCode(params) {
  return request({
    url: '/sys/selectAffiliateCode',
    method: 'post',
    data: { params },
  });
}

//  删除账户类型
export async function deleteAffiliateGrou(params) {
  return request({
    url: 'sys/deleteaffiliateGroup',
    method: 'get',
    params,
  });
}

// MT4范围列表
export async function mt4Scope(params) {
  return request({
    url: '/mt4/selectScope',
    method: 'post',
    data: { params },
  });
}
