import request from '@/utils/request';

export async function login(data) {
  return request({
    url: '/login/weblogin',
    method: 'post',
    data,
  });
}

export function getInfo(token) {
  return request({
    url: '/user/info',
    method: 'get',
    params: { token },
  });
}

export function logout() {
  return request({
    url: '/logout/weblogout',
    method: 'post',
  });
}
