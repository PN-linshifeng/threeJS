import request from '@/utils/request';

export async function queryList(params) {
  return request({
    url: '/role/selectRoleList',
    method: 'get',
    params,
  });
}

// 查询角色的权限
export async function queryRightByRole(params) {
  return request({
    url: '/role/selectRightByRole',
    method: 'get',
    params,
  });
}

// 添加角色权限
export async function addRightByRole(data) {
  return request({
    url: '/role/addRightByRole ',
    method: 'post',
    data,
  });
}

// 修改角色信息
export async function updateRole(data) {
  return request({
    url: '/role/updateRole ',
    method: 'post',
    data,
  });
}

// 添加角色
export async function addRole(data) {
  return request({
    url: '/role/addRole ',
    method: 'post',
    data,
  });
}

// 删除角色
export async function deleteRole(params) {
  return request({
    url: '/role/deleteRole',
    method: 'get',
    params,
  });
}
