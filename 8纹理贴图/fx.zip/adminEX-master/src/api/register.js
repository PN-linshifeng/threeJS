import request from '@/utils/request';

// 获取用户IP所在的城市
export function judgeCountry(params) {
  return request({
    url: '/reg/judgeCountry',
    method: 'get',
    params,
  });
}

// 获取注册协议
export function getAgreementList(params) {
  return request({
    url: '/reg/GetAgreementList',
    method: 'get',
    params,
  });
}

// 用户注册第一步form
export function register(data) {
  const params = JSON.stringify(data);
  return request({
    url: '/reg/register',
    method: 'post',
    data: { params },
  });
}

// 用户注册第二步form
export function regDetailed(data) {
  const params = JSON.stringify(data);
  return request({
    url: '/reg/RegDetailed',
    method: 'post',
    data: { params },
  });
}

// 问答返回数据
export function getRegQuestionnaire(params) {
  return request({
    url: '/reg/GetRegQuestionnaire',
    method: 'get',
    params,
  });
}

// 注册第二步初始化数据
export function initRegDetailedr(params) {
  return request({
    url: '/reg/InitRegDetailed',
    method: 'get',
    params,
  });
}
