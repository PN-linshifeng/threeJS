import request from '@/utils/request';

export async function queryList(params) {
  return request({
    url: '/campaign/selectADBanner',
    method: 'post',
    data: { params },
  });
}

export async function addADBanner(params) {
  return request({
    url: '/campaign/addADBanner',
    method: 'post',
    data: { params },
  });
}
