import request from '@/utils/request';

export async function queryList(params) {
  return request({
    url: '/campaign/selectADSrouce',
    method: 'post',
    data: { params },
  });
}

export async function addADSrouce(params) {
  return request({
    url: '/campaign/addADSrouce',
    method: 'post',
    data: { params },
  });
}
