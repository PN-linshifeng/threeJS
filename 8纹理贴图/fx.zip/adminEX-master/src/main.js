/* eslint-disable no-new */
/* eslint-disable global-require */
import Vue from 'vue';

import Cookies from 'js-cookie';
import moment from 'moment';
import 'moment/locale/zh-cn';
import ElTreeSelect from 'el-tree-select';

import 'normalize.css/normalize.css'; // a modern alternative to CSS resets

import Element from 'element-ui';
import './styles/element-variables.scss';

import '@/styles/index.scss'; // global css

import App from './App';
import store from './store';
import router from './router';

import i18n, { getLanguage, MyLang } from './lang'; // internationalization
import './icons'; // icon
import './permission'; // permission control
import './utils/error-log'; // error log

import * as filters from './filters'; // global filters

/**
 * If you don't want to use mock-server
 * you want to use MockJs for mock api
 * you can execute: mockXHR()
 *
 * Currently MockJs will be used in the production environment,
 * please remove it before going online ! ! !
 */
// if (process.env.NODE_ENV === 'production') {
//   const { mockXHR } = require('../mock');
//   mockXHR();
// }

Vue.prototype.$moment = moment;
moment.locale(getLanguage()); // 时间格式化默认中文
Vue.use(Element, {
  size: Cookies.get('size') || 'medium', // set element-ui default size
  i18n: (key, value) => i18n.t(key, value),
});

// register global utility filters
Object.keys(filters).forEach(key => {
  Vue.filter(key, filters[key]);
});

Vue.use(MyLang);
Vue.use(ElTreeSelect);

Vue.config.productionTip = false;

new Vue({
  el: '#app',
  router,
  store,
  i18n,
  computed: {
    lan() {
      return this.$i18n.locale;
    },
  },
  watch: {
    lan() {
      this.$setLang(this.$i18n);
    },
  },
  created() {
    this.$setLang(this.$i18n);
  },
  mounted() {
    // document.dispatchEvent(new Event('render-event'));
  },
  render: h => h(App),
});
