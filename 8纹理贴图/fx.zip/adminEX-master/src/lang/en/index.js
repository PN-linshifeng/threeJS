import config from './config';
import type from './type';

export default { ...config, ...type };
