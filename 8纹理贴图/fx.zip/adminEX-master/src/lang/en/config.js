export default {
  config: {
    login: 'Login',
    username: 'Username',
    password: 'Password',
    ln: '1',
    language: 'Language',
    'zh-cn': 'Chinese',
    en: 'English',
    addSuccess: '添加成功！',
    addError: '添加失败！',
    deleteSuccess: '删除成功！',
    deleteError: '删除失败！',
  },
};
