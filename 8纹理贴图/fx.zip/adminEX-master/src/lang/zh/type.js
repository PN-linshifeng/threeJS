export default {
  type: {
    systemType: '管理类型',
    account: '账户类型',
    document: '文档类别',
    data: '资料类别',
    mail: '邮件类别',
    clientType: '客户类型',
    client: '客户',
    ib: 'IB',
    clientIb: '客户IB',
    employee: '内部员工',
  },
};
