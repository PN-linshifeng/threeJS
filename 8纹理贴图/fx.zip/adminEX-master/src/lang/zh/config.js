export default {
  config: {
    login: '登录',
    username: '用户名',
    password: '密码',
    ln: '0',
    language: '语言',
    'zh-cn': '中文',
    en: '英文',
    addSuccess: '添加成功！',
    addError: '添加失败！',
    deleteSuccess: '删除成功！',
    deleteError: '删除失败！',
  },
};
