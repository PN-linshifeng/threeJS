import Vue from 'vue';
import VueI18n from 'vue-i18n';
import Cookies from 'js-cookie';
import elementEnLocale from 'element-ui/lib/locale/lang/en'; // element-ui lang
import elementZhLocale from 'element-ui/lib/locale/lang/zh-CN'; // element-ui lang

import enLocale from './en/index';
import zhLocale from './zh/index';
import en from './en';
import zh from './zh';

Vue.use(VueI18n);

const langList = [
  {
    ln: '0',
    code: 'zh-cn',
    'zh-cn': '中文',
    en: '英文',
  },
  {
    ln: '1',
    code: 'en',
    'zh-cn': 'Chinese',
    en: 'English',
  },
];

const messages = {
  'zh-cn': {
    ...zh,
    ...zhLocale,
    ...elementZhLocale,
    ...langList[0],
  },
  en: {
    ...en,
    ...enLocale,
    ...elementEnLocale,
    ...langList[1],
  },
};

export function getLanguage() {
  const chooseLanguage = Cookies.get('language');
  if (chooseLanguage) return chooseLanguage;

  // if has not choose language
  const language = (navigator.language || navigator.browserLanguage).toLowerCase();
  const locales = Object.keys(messages);
  for (const locale of locales) {
    if (language.indexOf(locale) > -1) {
      return locale;
    }
  }
  return 'zh-cn';
}
const i18n = new VueI18n({
  // set locale
  // options: en | zh | es
  locale: getLanguage(),
  // set locale messages
  messages,
});
// 插件(组件常用语言变量)
export const MyLang = {
  install(VUE) {
    VUE.prototype.$setLang = function resetLang(p) {
      VUE.prototype.$ln = Number(p.t('ln'));
      VUE.prototype.$langList = langList.map(k => ({
        text: p.t(k.code),
        code: k.code,
        ln: Number(k.ln),
      }));
    };
    VUE.prototype.$ln = 0;
  },
};
export default i18n;
