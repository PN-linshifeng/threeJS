import { queryList, updateModule, addModule, deleteModule } from '@/api/module';
import toTree from '@/utils/treeTotree';
// import toTree from '@/utils/treeTotree';

const stateDefault = {
  queryList: [],
  queryListLoading: false,
  addEditLoading: false,
};
const actions = {
  async queryList({ commit }, payload) {
    commit('SET_LOADING', { id: 'queryListLoading' });
    let resp;
    try {
      resp = await queryList(payload);
      commit('SET_QUERYLIST', resp);
    } catch (err) {
      resp = Promise.reject(err);
    }
    commit('SET_LOADING', { id: 'queryListLoading' });
    return resp;
  },
  async updateModule({ commit }, payload) {
    let resp;
    commit('SET_LOADING', { id: 'addEditLoading' });
    try {
      resp = await updateModule(payload);
    } catch (error) {
      resp = Promise.reject(error);
    }
    commit('SET_LOADING', { id: 'addEditLoading' });
    return resp;
  },
  async addModule({ commit }, payload) {
    let resp;
    commit('SET_LOADING', { id: 'addEditLoading' });
    try {
      resp = await addModule(payload);
    } catch (error) {
      resp = Promise.reject(error);
    }
    commit('SET_LOADING', { id: 'addEditLoading' });
    return resp;
  },
  async deleteModule({ commit }, payload) {
    let resp;
    commit('SET_LISTLOADING', { loading: 'deleteLoading', ...payload });
    try {
      resp = await deleteModule(payload);
      commit('SET_DELITE', payload);
    } catch (error) {
      resp = Promise.reject(error);
    }
    return resp;
  },
};

const mutations = {
  SET_QUERYLIST(state, payload) {
    state.queryList = payload;
  },
  SET_LOADING(state, payload) {
    state[payload.id] = !state[payload.id];
  },
  SET_LISTLOADING(state, payload) {
    const { queryList: data } = state;
    const { id, loading } = payload;
    const index = data.findIndex(k => k.id === id);
    data[index][loading] = !data[index][loading];
    state.queryList = [...data];
  },
  SET_DELITE(state, payload) {
    const { id } = payload;
    const newData = state.queryList.filter(k => k.id !== id);
    state.queryList = newData;
  },
};
const getters = {
  queryListFormat: state => {
    const data = state.queryList.map(k => ({ key: k.id, ...k }));
    const mapList = toTree(data);
    return mapList;
  },
};
export default {
  namespaced: true,
  state: stateDefault,
  mutations,
  actions,
  getters,
};
