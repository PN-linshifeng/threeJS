import queryList, { addOrg, updateOrg, deleteOrg } from '@/api/org';
import toTree from '@/utils/treeTotree';

const stateDefault = {
  queryList: [],
  queryListLoading: false,
  addOrgLoading: false,
};
const actions = {
  async queryList({ commit }, payload) {
    commit('SET_LOADING', { id: 'queryListLoading' });
    const resp = await queryList(payload);
    if (resp) {
      commit('SET_QUERYLIST', resp);
    }
    commit('SET_LOADING', { id: 'queryListLoading' });
    return resp;
  },
  // 添加
  async addOrg({ commit }, payload) {
    commit('SET_LOADING', { id: 'addOrgLoading' });
    let data;
    try {
      data = await addOrg(payload);
    } catch (error) {
      data = Promise.reject(error);
    }
    commit('SET_LOADING', { id: 'addOrgLoading' });
    return data;
  },
  // 更新
  async updateOrg(_, payload) {
    let data;
    try {
      data = await updateOrg(payload);
    } catch (error) {
      data = Promise.reject(error);
    }
    return data;
  },
  // 刪除 updateOrg
  async deleteOrg({ commit }, payload) {
    let data;
    commit('SET_LISTLOADING', { ...payload, loading: 'deleteLoading' });
    try {
      data = await deleteOrg(payload);
    } catch (error) {
      data = Promise.reject(error);
    }
    commit('SET_LISTLOADING', { ...payload, loading: 'deleteLoading' });
    return data;
  },
};

const mutations = {
  SET_QUERYLIST(state, payload) {
    state.queryList = payload;
  },
  SET_LOADING(state, payload) {
    state[payload.id] = !state[payload.id];
  },
  SET_LISTLOADING(state, payload) {
    const { queryList: data } = state;
    const { id, loading } = payload;
    const index = data.findIndex(k => k.id === id);
    data[index][loading] = !data[index][loading];
    state.queryList = [...data];
  },
  SET_DELITE(state, payload) {
    const { id } = payload;
    const newData = state.queryList.filter(k => k.id !== id);
    state.queryList = newData;
  },
};
const getters = {
  queryListFormat: state => {
    const data = state.queryList.map(k => ({ key: k.id, ...k }));
    const mapList = toTree(data);
    return mapList;
  },
};

export default {
  namespaced: true,
  state: stateDefault,
  mutations,
  actions,
  getters,
};
