import { queryList, queryRightByRole, addRightByRole, updateRole, addRole, deleteRole } from '@/api/role';
import toTree from '@/utils/treeTotree';

const defaultState = {
  queryList: [],
  queryListLoading: false,
  queryRole: [],
  updateRoleLoading: false,
  addRoleLoading: false,
};
const actions = {
  // 查询角色列表
  async queryList({ commit }, payload) {
    commit('SET_LOADING', { id: 'queryListLoading' });
    let resp;
    try {
      resp = await queryList(payload);
      commit('SET_QUERYLIST', resp);
    } catch (err) {
      resp = Promise.reject(err);
    }

    commit('SET_LOADING', { id: 'queryListLoading' });
    return resp;
  },
  // 查询角色权限
  async queryRoleById({ commit }, payload) {
    let resp;
    commit('SET_LISTLOADING', {
      loading: 'queryRoleByIdLoading',
      id: payload.roleids,
    });
    try {
      resp = await queryRightByRole(payload);
      commit('SET_QUERYROLEBYID', resp);
    } catch (err) {
      resp = Promise.reject(err);
    }

    commit('SET_LISTLOADING', {
      loading: 'queryRoleByIdLoading',
      id: payload.roleids,
    });
    return resp;
  },
  // 添加角色权限
  async addRightByRole(_, payload) {
    const resp = await addRightByRole(payload);
    return resp;
  },
  // 添加角色
  async addRole({ commit }, payload) {
    let resp;
    commit('SET_LOADING', { id: 'addRoleLoading' });
    try {
      resp = await addRole(payload);
    } catch (err) {
      resp = Promise.reject(err);
    }
    commit('SET_LOADING', { id: 'addRoleLoading' });
    return resp;
  },
  // 修改角色
  async updateRole({ commit }, payload) {
    let resp;
    commit('SET_LOADING', { id: 'updateRoleLoading' });
    try {
      resp = await updateRole(payload);
    } catch (err) {
      resp = Promise.reject(err);
    }
    commit('SET_LOADING', { id: 'updateRoleLoading' });
    return resp;
  },
  async deleteRole({ commit }, payload) {
    let resp;
    commit('SET_LISTLOADING', { loading: 'deleteLoading', ...payload });
    try {
      resp = await deleteRole(payload);
      commit('SET_DELITE', payload);
    } catch (err) {
      resp = Promise.reject(err);
    }
    return resp;
  },
};
const mutations = {
  SET_QUERYLIST(state, payload) {
    state.queryList = payload;
  },
  SET_LOADING(state, payload) {
    state[payload.id] = !state[payload.id];
  },
  SET_QUERYROLEBYID(state, payload) {
    state.queryRole = payload;
  },
  SET_LISTLOADING(state, payload) {
    const { queryList: data } = state;
    const { id, loading } = payload;
    const index = data.findIndex(k => k.id === id);
    data[index][loading] = !data[index][loading];
    state.queryList = [...data];
  },
  SET_DELITE(state, payload) {
    const { id } = payload;
    const newData = state.queryList.filter(k => k.id !== id);
    state.queryList = newData;
  },
};

const getters = {
  queryListFormat: state => {
    const data = state.queryList.map(k => ({ key: k.id, ...k }));
    const mapList = toTree(data);
    return mapList;
  },
};

export default {
  namespaced: true,
  state: defaultState,
  actions,
  mutations,
  getters,
};
