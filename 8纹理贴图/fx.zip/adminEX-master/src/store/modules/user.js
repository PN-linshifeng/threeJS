/* eslint-disable prefer-promise-reject-errors */
import { login, logout, getInfo } from '@/api/user';
import { getToken, setToken, removeToken } from '@/utils/auth';
import router, { resetRouter } from '@/router';

const getDefaultState = () => ({
  token: getToken(),
  name: '',
  avatar: '',
  introduction: '',
  roles: [],
  moduleList: JSON.parse(window.localStorage.getItem('aside')) || [],
  user: {},
});

const stateDefault = getDefaultState();

const mutations = {
  RESET_STATE: state => {
    Object.assign(state, getDefaultState());
  },
  SET_TOKEN: (state, token) => {
    state.token = token;
  },
  SET_INTRODUCTION: (state, introduction) => {
    state.introduction = introduction;
  },
  SET_NAME: (state, name) => {
    state.name = name;
  },
  SET_AVATAR: (state, avatar) => {
    state.avatar = avatar;
  },
  SET_ROLES: (state, roles) => {
    state.roles = roles;
  },
  SET_LOGININFI: (state, { user, moduleList }) => {
    state.user = user;
    // state.aside = aside;
    state.moduleList = moduleList;
  },
  SET_ASIDE: (state, data) => {
    let moduleList;
    if (data.id) {
      moduleList = state.moduleList.map(k => {
        if (k.id === data.id) {
          return {
            ...k,
            ...data,
          };
        }
        return k;
      });
    } else {
      moduleList = [...state.moduleList, ...data];
    }
    window.localStorage.setItem('aside', JSON.stringify(moduleList));
    state.moduleList = moduleList;
  },
  SET_DELITEASIDE(state, payload) {
    const { id } = payload;
    const newData = state.moduleList.filter(k => k.id !== id);
    window.localStorage.setItem('aside', JSON.stringify(newData));
    state.moduleList = newData;
  },
  SET_RESETASIDE(state, payload) {
    state.moduleList = payload;
    window.localStorage.setItem('aside', JSON.stringify(payload));
  },
};

const actions = {
  // user login
  async login({ commit }, userInfo) {
    // const { username, password, ln } = userInfo;
    const resp = await login(userInfo);
    commit('SET_TOKEN', 'admin-token');
    setToken('admin-token');
    commit('SET_LOGININFI', {
      user: resp.user,
      moduleList: resp.modulelist,
    });
    window.localStorage.setItem('aside', JSON.stringify(resp.modulelist));
    window.localStorage.setItem('user', resp.user);
    // return resp;
  },

  // user logout
  logout({ commit, state }) {
    removeToken(); // must remove  token  first
    resetRouter();
    return new Promise((resolve, reject) => {
      logout(state.token)
        .then(() => {
          removeToken(); // must remove  token  first
          resetRouter();
          commit('RESET_STATE');
          resolve();
        })
        .catch(error => {
          reject(error);
        });
    });
  },

  // remove token
  resetToken({ commit }) {
    return new Promise(resolve => {
      removeToken(); // must remove  token  first
      commit('RESET_STATE');
      resolve();
    });
  },

  // 修改aside
  editAside({ commit }, payload) {
    commit('SET_ASIDE', payload);
  },
  // 修改aside
  deleteAside({ commit }, payload) {
    commit('SET_DELITEASIDE', payload);
  },
  // 重置aside
  resetAside({ commit }, payload) {
    commit('SET_RESETASIDE', payload);
  },

  // get user info
  getInfo({ commit, state }) {
    return new Promise((resolve, reject) => {
      getInfo(state.token)
        .then(response => {
          const { data } = response;

          if (!data) {
            reject('Verification failed, please Login again.');
          }

          const { roles, name, avatar, introduction } = data;

          // roles must be a non-empty array
          if (!roles || roles.length <= 0) {
            reject('getInfo: roles must be a non-null array!');
          }

          commit('SET_ROLES', roles);
          commit('SET_NAME', name);
          commit('SET_AVATAR', avatar);
          commit('SET_INTRODUCTION', introduction);
          resolve(data);
        })
        .catch(error => {
          reject(error);
        });
    });
  },

  // dynamically modify permissions
  async changeRoles({ commit, dispatch }, role) {
    const token = `${role}-token`;

    commit('SET_TOKEN', token);
    setToken(token);

    const { roles } = await dispatch('getInfo');

    resetRouter();

    // generate accessible routes map based on roles
    const accessRoutes = await dispatch('permission/generateRoutes', roles, {
      root: true,
    });
    // dynamically add accessible routes
    router.addRoutes(accessRoutes);

    // reset visited views and cached views
    dispatch('tagsView/delAllViews', null, { root: true });
  },
};

export default {
  namespaced: true,
  state: stateDefault,
  mutations,
  actions,
};
