import Layout from '@/layout';

export default [
  {
    path: '/admin/profile',
    component: Layout,
    children: [
      {
        path: 'upload',
        name: 'upload',
        component: () => import('@/views/profile/upload/index'),
        meta: { title: '上传资料' },
      },
    ],
  },
];
