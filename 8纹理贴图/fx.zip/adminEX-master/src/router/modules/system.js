import Layout from '@/layout';

export default [
  {
    path: '/admin/system',
    component: Layout,
    children: [
      {
        path: 'user',
        name: 'systemUser',
        component: () => import('@/views/system/user/index'),
        meta: { title: '用户管理', keep: true },
      },
      {
        path: 'account-type',
        name: 'system account type',
        component: () => import('@/views/system/accountType/index'),
        meta: { title: '账户类型', keep: true },
      },
      {
        path: 'type',
        name: 'system type',
        component: () => import('@/views/system/type/index'),
        meta: { title: '类型管理' },
      },
      {
        path: 'log',
        name: 'system log',
        component: () => import('@/views/system/log/index'),
        meta: { title: '日志' },
      },
    ],
  },
];
