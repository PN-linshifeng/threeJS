import Layout from '@/layout';

export default [
  {
    path: '/admin/promo',
    component: Layout,
    children: [
      {
        path: 'campaign',
        name: 'promo campaign',
        component: () => import('@/views/promo/campaign/index'),
        meta: { title: '活动列表' },
      },
      {
        path: 'adsource',
        name: 'promo ADSource',
        component: () => import('@/views/promo/ADSource/index'),
        meta: { title: '媒体来源' },
      },
      {
        path: 'landpage',
        name: 'promo ADLandPage',
        component: () => import('@/views/promo/ADLandPage/index'),
        meta: { title: '着陆页' },
      },
      {
        path: 'banner',
        name: 'promo banner',
        component: () => import('@/views/promo/banner/index'),
        meta: { title: '广告管理' },
      },
    ],
  },
];
