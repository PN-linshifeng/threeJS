import Layout from '@/layout';

export default [
  {
    path: '/admin/bill',
    component: Layout,
    children: [
      {
        path: 'deposit',
        name: 'Deposit',
        component: () => import('@/views/bill/deposit/index'),
        meta: { title: '入金' },
      },
    ],
  },
];
