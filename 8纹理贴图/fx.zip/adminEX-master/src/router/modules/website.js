import layout from '@/layout/website';

const website = [
  {
    path: '/',
    component: layout,
    hidden: true,
    children: [
      {
        path: 'register/live',
        name: 'RegisterLive',
        component: () => import('@/views/register/step-1/index'),
        meta: { title: '真实注册' },
      },
      {
        path: 'register/ib',
        name: 'RegisterIB',
        component: () => import('@/views/register/step-1/index'),
        meta: { title: 'IB注册' },
      },
      {
        path: 'register/demo',
        name: 'RegisterDemo',
        component: () => import('@/views/register/step-1/index'),
        meta: { title: '模拟账户注册' },
      },
      {
        path: 'register/info',
        name: 'RegisterInfo',
        component: () => import('@/views/register/step-2/index'),
        meta: { title: '提交个人资料' },
      },
    ],
  },
];

export default website;
