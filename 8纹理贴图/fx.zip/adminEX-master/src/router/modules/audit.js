import Layout from '@/layout';

export default [
  {
    path: '/admin/audit',
    component: Layout,
    children: [
      {
        path: 'document',
        name: 'Document',
        component: () => import('@/views/audit/document/index'),
        meta: { title: '资料审核' },
      },
    ],
  },
];
