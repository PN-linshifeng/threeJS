import Layout from '@/layout';

export default [
  {
    path: '/admin/system',
    component: Layout,
    children: [
      {
        path: 'user',
        name: 'systemUser',
        component: () => import('@/views/system/user/index'),
        meta: { title: '用户管理' },
      },
      {
        path: 'account-type',
        name: 'system account type',
        component: () => import('@/views/system/accountType/index'),
        meta: { title: '账户类型' },
      },
      {
        path: 'type',
        name: 'system type',
        component: () => import('@/views/system/type/index'),
        meta: { title: '类型管理' },
      },
    ],
  },
];
