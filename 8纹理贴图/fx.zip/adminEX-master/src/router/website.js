import layout from '@/layout/website';

const website = [
  {
    path: '/',
    component: layout,
    hidden: true,
    children: [
      {
        path: 'register-live',
        name: 'register-live',
        component: () => import('@/views/register/step-1/index'),
        meta: { title: '真实注册' },
      },
      {
        path: 'register-info',
        name: 'register info',
        component: () => import('@/views/register/step-2/index'),
        meta: { title: '提交个人资料' },
      },
    ],
  },
];

export default website;
