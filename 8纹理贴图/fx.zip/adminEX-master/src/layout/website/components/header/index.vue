<template>
  <div class="header">
    <router-link to="/register-live">真实账户注册</router-link>
    <router-link to="/register-ib">IB 注册</router-link>
    <router-link to="/register-demo">模拟账户注册</router-link>
  </div>
</template>
