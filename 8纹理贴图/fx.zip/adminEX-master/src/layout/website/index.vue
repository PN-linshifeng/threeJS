<template>
  <div class="website-layout">
    <div class="header" style="padding:25px;">
      <router-link to="/admin">商务中心</router-link>
    </div>
    <div class="main">
      <transition name="fade-transform" mode="out-in">
        <router-view :key="key" />
      </transition>
    </div>
    <div class="footer">底部</div>
  </div>
</template>
<script>
export default {
  name: 'AppMain',
  computed: {
    key() {
      return this.$route.path;
    },
  },
};
</script>
