<template>
  <div :class="{'has-logo':showLogo}">
    <logo v-if="showLogo" :collapse="isCollapse" />
    <el-scrollbar wrap-class="scrollbar-wrapper">
      <el-menu
        :default-active="activeMenu"
        :collapse="isCollapse"
        :background-color="variables.menuBg"
        :text-color="variables.menuText"
        :unique-opened="false"
        :active-text-color="variables.menuActiveText"
        :collapse-transition="false"
        mode="vertical"
      >
        <sidebar-item
          v-for="route in routes"
          :key="route.path"
          :item="route"
          :base-path="route.path"
        />
      </el-menu>
    </el-scrollbar>
  </div>
</template>

<script>
import { mapGetters, mapState } from 'vuex';
import variables from '@/styles/variables.scss';
import toTree from '@/utils/treeTotree';
import Logo from './Logo';
import SidebarItem from './SidebarItem';

export default {
  components: { SidebarItem, Logo },
  data() {
    return {
      routes: this.getAside(),
    };
  },
  computed: {
    ...mapGetters(['permission_routes', 'sidebar']),
    ...mapState({
      moduleList: state => state.user.moduleList,
    }),
    activeMenu() {
      const route = this.$route;
      const { meta, path } = route;
      // if set path, the sidebar will highlight the path you set
      if (meta.activeMenu) {
        return meta.activeMenu;
      }
      return path;
    },
    showLogo() {
      return this.$store.state.settings.sidebarLogo;
    },
    variables() {
      return variables;
    },
    isCollapse() {
      return !this.sidebar.opened;
    },
  },

  watch: {
    moduleList() {
      this.routes = this.getAside();
    },
  },

  methods: {
    getAside() {
      const moduleList = JSON.parse(window.localStorage.getItem('aside'));
      let aside = [];
      if (moduleList) {
        aside = moduleList.map(k => ({
          path: k.url || `/${k.id}`,
          id: k.id,
          pid: k.pid,
          meta: { title: k.name, icon: k.icon },
        }));
      }

      aside = toTree(aside);
      return aside;
    },
  },
};
</script>
