<template>
  <div class="app-container">
    <el-row class="actionForm">
      <el-col>
        <el-form ref="searchForm" v-model="searchForm" inline @submit.native.prevent="searchSubmit">
          <el-form-item prop="content">
            <el-input v-model="searchForm.content" size="small" />
          </el-form-item>
          <el-form-item>
            <el-button icon="el-icon-search" size="small" native-type="submit" type="primary">搜索</el-button>
          </el-form-item>
        </el-form>
      </el-col>
    </el-row>
    <el-row style="margin-bottom:24px">
      <el-col :span="24">
        <el-table
          v-loading="queryListLoading"
          :data="queryList.data"
          :row-class-name="tableRowClassName"
        >
          >
          <el-table-column label="类型" prop="type" width="80px">
            <template slot-scope="scope">{{ type.get(scope.row.type) }}</template>
          </el-table-column>
          <el-table-column label="状态" prop="level" width="80px">
            <template slot-scope="scope">{{ level.get(scope.row.level) }}</template>
          </el-table-column>
          <el-table-column label="IP" prop="ip" width="120px" />
          <el-table-column label="参数" prop="params" />
          <el-table-column label="内容" prop="content" />
        </el-table>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="24">
        <el-pagination
          background
          layout="prev, pager, next"
          :total="queryList.total"
          :current-page.sync="queryList.pageNum"
          :page-size="queryList.pageSize"
          class="fx-text-right"
          @current-change="pageChange"
        />
      </el-col>
    </el-row>
  </div>
</template>
<script>
import queryLog from '@/api/systemLog';

const level = new Map([
  [1, '正常'],
  [2, '警告'],
  [3, '错误'],
]);
const type = new Map([
  [1, '登录'],
  [2, '插入'],
  [3, '更新'],
  [4, '删除'],
]);
export default {
  data() {
    return {
      queryListLoading: false,
      queryList: {},
      searchForm: {},
      searchData: {
        pageNum: 1,
        pageSize: 10,
      },
      level,
      type,
    };
  },
  mounted() {
    this.initData();
  },
  methods: {
    // 数据初始化
    initData() {
      this.queryLog();
    },
    // 列表
    queryLog() {
      this.queryListLoading = true;
      queryLog(this.searchData)
        .then(data => {
          this.queryList = data;
          this.queryListLoading = false;
        })
        .catch(() => {
          this.queryListLoading = false;
        });
    },
    // 分页
    pageChange(page) {
      this.searchData.pageNum = page;
      this.queryLog();
    },

    // 搜索
    searchSubmit() {
      this.searchData = { ...this.searchData, ...this.searchForm };
      this.queryLog();
    },

    // 表格行样式
    tableRowClassName({ row }) {
      const { level: state } = row;
      if (state === 2) {
        return 'warning-row';
      }
      if (state === 3) {
        return 'danger-row';
      }
      return '';
    },
  },
};
</script>
