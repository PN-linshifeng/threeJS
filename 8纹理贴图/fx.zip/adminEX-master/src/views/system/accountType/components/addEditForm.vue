<template>
  <editDialog :visible="visible" :submit-loading="submitLoading" @close="close" @submit="submit">
    <el-form ref="addForm" :model="addForm" :rules="addFormRules" label-width="120px">
      <el-form-item :label="$t('config.language')+'：'" prop="langid">
        <el-select v-model="addForm.langid">
          <el-option label="全部" :value="-1">全部</el-option>
          <el-option v-for="k of $langList" :key="k.ln" :value="k.ln" :label=" k.text " />
        </el-select>
      </el-form-item>
      <el-form-item label="web组：" prop="name">
        <el-input v-model="addForm.name" placeholder="请输入内容" />
      </el-form-item>
      <el-form-item label="MT4组：" prop="mt4groupid">
        <el-select v-model="addForm.mt4groupid" placeholder="请选择" style="min-width:100%">
          <el-option
            v-for="item in mtgroupList.data"
            :key="item.id"
            :label="item.mtgroup"
            :value="item.id"
          />
        </el-select>
      </el-form-item>

      <el-form-item label="账户类型：" prop="acctypeid">
        <el-select v-model="addForm.acctypeid" placeholder="请选择" style="min-width:100%">
          <el-option
            v-for="item in typeList.data"
            :key="item.id"
            :label="item.name"
            :value="item.id"
          >
            <span style="float: left">{{ item.name }}</span>
            <span
              style="float: right; color: #8492a6; font-size: 13px"
            >{{ item.clientype===1?'客户':'IB' }}</span>
          </el-option>
        </el-select>
      </el-form-item>

      <el-form-item label="佣金编码：" prop="codeid">
        <el-select v-model="addForm.codeid" placeholder="请选择" style="min-width:100%">
          <el-option
            v-for="item in codeList.data"
            :key="item.id"
            :label="item.code"
            :value="item.id"
          />
        </el-select>
      </el-form-item>

      <el-form-item label="账号范围：" prop="scopeid">
        <el-select v-model="addForm.scopeid" placeholder="请选择" style="min-width:100%">
          <el-option
            v-for="item of mtScopeList"
            :key="item.id"
            :value="item.id"
            :label="item.start+'-'+item.end"
          >
            <span style="float: left">{{ item.start }}-{{ item.end }}</span>
            <span style="float: right; color: #8492a6; font-size: 13px">{{ item.desc }}</span>
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="货币：" prop="currency">
        <el-input v-model="addForm.currency" />
      </el-form-item>
      <el-form-item label="入金金额：" prop="mininitial">
        <el-col class="line" :span="11">
          <el-input v-model="addForm.mininitial" placeholder="最小入金" />
        </el-col>
        <el-col class="line fx-text-center" :span="2">-</el-col>
        <el-col class="line" :span="11">
          <el-form-item prop="maxinitial">
            <el-input v-model="addForm.maxinitial" placeholder="最大入金" />
          </el-form-item>
        </el-col>
      </el-form-item>
      <el-form-item label="入金范围：" prop="mindeposit">
        <el-col class="line" :span="11">
          <el-input v-model="addForm.mindeposit" placeholder="最小入金" />
        </el-col>
        <el-col class="line fx-text-center" :span="2">-</el-col>
        <el-col class="line" :span="11">
          <el-form-item prop="maxdeposit">
            <el-input v-model="addForm.maxdeposit" placeholder="最大入金" />
          </el-form-item>
        </el-col>
      </el-form-item>
      <el-form-item label="出金范围：" prop="minwithdraw">
        <el-col class="line" :span="11">
          <el-input v-model="addForm.minwithdraw" placeholder="最小出金" />
        </el-col>
        <el-col class="line fx-text-center" :span="2">-</el-col>
        <el-col class="line" :span="11">
          <el-form-item prop="maxwithdraw">
            <el-input v-model="addForm.maxwithdraw" placeholder="最大出金" />
          </el-form-item>
        </el-col>
      </el-form-item>
    </el-form>
  </editDialog>
</template>
<script>
import editDialog from '@/components/EditDialog';

export default {
  components: { editDialog },
  props: {
    visible: { required: true, type: Boolean, default: false },

    submitLoading: { required: true, type: Boolean, default: false },
    type: { required: true, type: String, default: 'add' },
    mtgroupList: {
      required: true,
      type: Object,
    },
    codeList: {
      required: true,
      type: Object,
    },
    typeList: {
      required: true,
      type: Object,
    },
    mtScopeList: {
      required: true,
      type: Array,
    },
    row: {
      required: false,
      type: Object,
      default() {
        return {};
      },
    },
  },
  data() {
    return {
      action: 'add', // 添加 edit修改
      // 添加修改Form
      addForm: {
        langid: this.$ln,
      },
      // 验证
      addFormRules: {
        name: [{ required: true, message: '名称不能为空', trigger: ['change', 'blur'] }],
        acctypeid: [{ required: true, message: '不能为空', trigger: 'change' }],
        codeid: [{ required: true, message: '不能为空', trigger: 'change' }],
        mt4groupid: [{ required: true, message: '不能为空', trigger: 'change' }],
      },
    };
  },
  watch: {
    row() {
      if (this.$refs.addForm) {
        this.$refs.addForm.resetFields();
      }
      this.$nextTick(() => {
        this.addForm = {
          ...this.addForm,
          ...this.row,
        };
      });
    },
  },
  created() {},
  methods: {
    // 选择语言
    handleLangChange() {
      this.addForm.checkLanguage.sort();
    },

    // 关闭
    close() {
      this.$emit('close');
      this.$refs.addForm.resetFields();
    },

    // 提交添加角色或者修改角色
    submit() {
      this.$refs.addForm.validate(async (valid) => {
        if (valid) {
          this.$emit('submit', this.addForm);
        }
      });
    },
  },
};
</script>
