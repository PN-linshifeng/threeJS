<template>
  <el-form ref="form" inline :data="form">
    <el-form-item label="账户类型：" prop="acctypeid">
      <el-select v-model="form.acctypeid" size="small" class="select-width">
        <el-option value label="全部" />
        <el-option v-for="item in typeList.data" :key="item.id" :label="item.name" :value="item.id">
          <span style="float: left">{{ item.name }}</span>
          <span
            style="float: right; color: #8492a6; font-size: 13px"
          >{{ item.clientype===1?'客户':'IB' }}</span>
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="佣金编码：" prop="codeid">
      <el-select v-model="form.codeid" size="small" class="select-width">
        <el-option value label="全部" />
        <el-option
          v-for="item in codeList.data"
          :key="item.id"
          :label="item.code"
          :value="item.id"
        />
      </el-select>
      <el-form-item style=" margin-left:8px">
        <el-button size="small" type="primary" @click="handleSearch">搜 索</el-button>
      </el-form-item>
    </el-form-item>
  </el-form>
</template>
<script>
export default {
  props: {
    codeList: {
      required: true,
      type: Object,
    },
    typeList: {
      required: true,
      type: Object,
    },
  },
  data() {
    return {
      form: {},
    };
  },
  methods: {
    handleSearch() {
      this.$emit('search', this.form);
    },
  },
};
</script>

<style lang="scss">
.select-width input {
  width: 150px;
}
</style>
