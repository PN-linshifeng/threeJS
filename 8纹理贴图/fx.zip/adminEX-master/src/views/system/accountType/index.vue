<template>
  <div class="app-container">
    <el-row style="margin-bottom:20px">
      <el-col :xs="12" :sm="12" :span="12">
        <el-button type="primary" icon="el-icon-plus" size="small" @click="addEditFormShow()">添加账户</el-button>
      </el-col>
      <el-col :xs="24" :sm="12" :span="12" class="fx-text-right">
        <seach-form :code-list="codeList" :type-list="typeList" @search="search" />
      </el-col>
    </el-row>
    <el-row style="margin-bottom:20px">
      <el-col>
        <el-table
          v-loading="queryListLoading"
          :data="dataList.data"
          style="width: 100%;margin-bottom: 20px;"
          row-key="id"
          @sort-change="sortChange"
        >
          <el-table-column prop="webgroup" label="Web组" />
          <el-table-column prop="mt4group" label="MT4组名称" />
          <el-table-column prop="typename" label="账户类型" sortable="custom" />
          <el-table-column
            prop="clientype"
            label="客户类型"
            :formatter="formatClientType"
            sortable="custom"
          />
          <el-table-column prop="hostname" label="主机名" />
          <el-table-column prop="code" label="佣金编码" sortable="custom" />
          <el-table-column prop="langid" label="语言" :formatter="formatLanguage" sortable="custom" />

          <el-table-column prop="currency" label="货币" sortable="custom" />
          <el-table-column label="操作" :width="270">
            <template slot-scope="scope">
              <el-button type="primary" size="mini" icon="el-icon-edit">修改</el-button>
              <el-button
                type="danger"
                size="mini"
                icon="el-icon-delete"
                :loading="scope.row.deleteLoading"
                @click="deleteAffiliateGrou(scope.row.id)"
              >删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <el-pagination
          background
          layout="prev, pager, next"
          :total="dataList.total"
          :current-page="dataList.pageNum"
          :page-size="dataList.pageSize"
          class="fx-text-right"
          @current-change="pageChange"
        />
      </el-col>
    </el-row>
    <!--添加修改弹框-->
    <add-edit-form
      v-loading="promiseAllLoading"
      element-loading-background="rgba(0, 0, 0, 0)"
      :visible="addEditFormVisible"
      :mtgroup-list="mtgroupList"
      :code-list="codeList"
      :type-list="typeList"
      :mt-scope-list="mtScopeList"
      :row="editRow"
      :type="addEditType"
      :submit-loading="addEditFormSubmitLoading"
      @close="addEditFormClose"
      @submit="addEditFormSubmit"
    />
  </div>
</template>
<script>
import {
  queryList,
  addAffiliateGroup,
  queryMt4Group,
  queryAffiliateCode,
  deleteAffiliateGrou,
  mt4Scope,
} from '@/api/systemAccountType';
import { queryList as queryTypeList } from '@/api/systemType';
import { clientType } from '@/utils/type';
import addEditForm from './components/addEditForm';
import SeachForm from './components/SearchForm';

export default {
  components: {
    addEditForm,
    SeachForm,
  },
  data() {
    return {
      // loading 参数
      queryListLoading: false,
      dataList: {},
      searchParams: {
        ln: this.$ln,
        pageNum: 1,
        pageSize: 10,
        sortby: '',
        desc: '',
        // langid: 0,
        // orderBy: 'createtime',
        // sort: 'desc',
      },
      clientType, // 客户类型

      // 以下全部是添加修改角色配置
      addEditFormVisible: false,
      promiseAllLoading: false,
      editRow: {},
      addEditType: 'add',
      addEditFormSubmitLoading: false,
      typeList: {}, // 账户类型
      codeList: {}, // 佣金编码
      mtgroupList: {}, // MT组
      mtScopeList: [], // MT账户范围
    };
  },

  computed: {},

  created() {
    this.initData();
  },
  methods: {
    // 数据初始化
    async initData() {
      this.queryList();

      const params = {
        pageNum: 0,
        pageSize: 100,
        orderBy: 'createtime',
        sort: 'desc',
      };
      const [mtgroupList, codeList, typeList] = await Promise.all([
        queryMt4Group(params),
        queryAffiliateCode(params),
        queryTypeList({
          type: 1,
          ln: this.$ln,
          ...params,
        }),
      ]);
      this.mtgroupList = mtgroupList;
      this.codeList = codeList;
      this.typeList = typeList;
    },

    // 查询列表
    queryList() {
      this.queryListLoading = true;
      queryList(this.searchParams)
        .then((resp) => {
          this.dataList = resp;
          this.queryListLoading = false;
        })
        .catch(() => {
          this.queryListLoading = false;
        });
    },
    // 分页
    pageChange(page) {
      this.searchParams.pageNum = page;
      this.queryList();
    },
    // 关键字排序
    sortChange({ prop, order }) {
      if (order) {
        this.searchParams.desc = order === 'ascending' ? 'asc' : 'desc';
        switch (prop) {
          case 'typename':
            this.searchParams.sortby = 'acctypeid';
            break;
          case 'code':
            this.searchParams.sortby = 'codeid';
            break;
          default:
            this.searchParams.sortby = prop;
        }
      } else {
        this.searchParams.desc = order;
        this.searchParams.sortby = '';
      }
      this.queryList();
    },
    // 搜索
    search(params) {
      this.searchParams = { ...this.searchParams, ...params, desc: '', sortby: '' };
      this.queryList();
    },

    // 时间格式化
    time(row, column, cellValue) {
      return this.$moment(cellValue).format('YYYY-MM-DD');
    },
    // 语言格式化
    formatLanguage(row, column, cellValue) {
      const item = this.$langList.find((k) => k.ln === cellValue);
      return (item && item.text) || '全部';
    },
    // 客户格式化
    formatClientType(row, column, cellValue) {
      return this.$te(`type.${clientType.get(cellValue)}`) ? this.$t(`type.${clientType.get(cellValue)}`) : '';
    },

    /**
     * 以下是添加修改角色的全部方法
     */
    // 关闭弹窗
    addEditFormClose() {
      this.editRow = {};
      this.addEditFormVisible = false;
    },
    // 打开弹窗
    async addEditFormShow(row) {
      this.addEditFormVisible = true;
      const params = {
        pageNum: 0,
        pageSize: 100,
        orderBy: 'createtime',
        sort: 'desc',
      };
      if (row) {
        this.editRow = row;
        this.addEditType = 'edit';
      } else {
        this.addEditType = 'add';
      }

      if (this.mtScopeList.length <= 0) {
        try {
          this.promiseAllLoading = true;
          const mtScopeList = await mt4Scope(params);
          this.mtScopeList = mtScopeList;
        } finally {
          this.promiseAllLoading = false;
        }
      }
    },
    // 提交弹窗form
    async addEditFormSubmit(params) {
      this.addEditFormSubmitLoading = true;

      let request;
      if (this.addEditType === 'add') {
        request = addAffiliateGroup;
      } else {
        request = 'updata';
      }
      try {
        await request(params);
        this.addEditFormClose();
        this.queryList();
      } finally {
        this.addEditFormSubmitLoading = false;
      }
    },

    // 删除
    deleteAffiliateGrou(id) {
      this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(async () => {
          const { data } = this.dataList;
          const index = data.findIndex((k) => k.id === id);
          data[index].deleteLoading = true;
          this.$set(this.dataList, 'data', [...data]);
          try {
            await deleteAffiliateGrou({ id });
            this.$message.success('操作成功');
            this.queryList();
          } catch (err) {
            data[index].deleteLoading = false;
            this.$set(this.dataList, 'data', [...data]);
          }
        })
        .catch(() => {
          this.$message.info('取消操作');
        });
    },
  },
};
</script>
