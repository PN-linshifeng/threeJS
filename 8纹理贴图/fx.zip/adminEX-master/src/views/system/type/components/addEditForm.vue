<template>
  <editDialog :visible="visible" :submit-loading="submitLoading" @close="close" @submit="submit">
    <el-form ref="addForm" :model="addForm" :rules="addFormRules" label-width="120px">
      <el-form-item label="名称" prop="checkLanguage">
        <el-checkbox-group v-model="addForm.checkLanguage" @change="handleLangChange">
          <el-checkbox
            v-for="(value, name) in $langList"
            :key="name"
            :label="value.ln"
          >{{ value.text }}</el-checkbox>
        </el-checkbox-group>
      </el-form-item>
      <el-form-item
        v-for="(k, index) of addForm.checkLanguage"
        :key="k"
        :label="$langList[k].text"
        prop="typenames"
      >
        <el-input v-model="addForm.typenames[index]" placeholder="请输入内容" />
      </el-form-item>
      <el-form-item label="类型" prop="type">
        <el-select v-model="addForm.type">
          <el-option
            v-for="(value,key) in typeList"
            :key="key"
            :label="$t('type.'+value[1])"
            :value="value[0]"
          />
        </el-select>
      </el-form-item>
      <el-form-item v-if="addForm.type!==2" label="真实账号">
        <el-radio-group v-model="addForm.islive">
          <el-radio :label="1">是</el-radio>
          <el-radio :label="0">否</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item v-if="addForm.type!==2" prop="num" label="序号">
        <el-input v-model="addForm.num" />
      </el-form-item>
      <el-form-item v-else prop="strid" label="文档类型">
        <el-select v-model="addForm.strid" multiple style=" width:100%">
          <el-option v-for="k of docTypeList" :key="k.id" :label="k.doctypename" :value="k.id" />
        </el-select>
      </el-form-item>
      <el-form-item label="组织" prop="orgid">
        <el-tree-select
          ref="orgTreeSelect"
          key="orgTreeSelect"
          v-model="addForm.orgid"
          :select-params="orgSelectParams"
          :tree-params="orgTreeParams"
        />
      </el-form-item>

      <el-form-item prop="clientype" :label="$t('type.clientType')">
        <el-select v-model="addForm.clientype">
          <el-option v-for="k of clientType" :key="k[0]" :value="k[0]" :label="$t('type.'+k[1])" />
          <!-- <el-option :value="2" label="IB">IB</el-option> -->
        </el-select>
      </el-form-item>

      <el-form-item prop="remarks" label="备注">
        <el-input v-model="addForm.remarks" type="textarea" />
      </el-form-item>
    </el-form>
  </editDialog>
</template>
<script>
import editDialog from '@/components/EditDialog';
import { clientType } from '@/utils/type';

export default {
  components: { editDialog },
  props: {
    visible: { required: true, type: Boolean, default: false },
    submitLoading: { required: true, type: Boolean, default: false },
    type: { required: true, type: String, default: 'add' },
    docTypeList: {
      required: true,
      type: Array,
      default() {
        return [];
      },
    },
    typeList: {
      required: true,
      type: Map,
    },
    row: {
      required: false,
      type: Object,
      default() {
        return {};
      },
    },
    orgTree: {
      required: false,
      type: Array,
      default() {
        return [];
      },
    },
  },
  data() {
    const typenames = (rule, value, callback) => {
      if (!value) {
        return callback(new Error('请输入内容'));
      }
      const flag = value.every((k) => k.length > 0);
      if (!flag || value.length <= 0) {
        return callback(new Error('请输入内容'));
      }
      return callback();
    };
    return {
      clientType, // 客户类型
      // 添加修改Form
      addForm: {
        checkLanguage: [0],
        pid: '',
        islive: 1,
        typenames: [],
        remarks: '',
      },
      // 验证
      addFormRules: {
        checkLanguage: [
          {
            type: 'array',
            required: true,
            message: '请至少选择一个语言',
            trigger: 'change',
          },
        ],
        typenames: [{ required: true, validator: typenames, trigger: 'blur' }],
        num: [{ required: true, message: '不能为空', trigger: 'blur' }],
        orgid: [{ required: true, message: '请选择组织', trigger: 'change' }],
        type: [{ required: true, message: '请选择类型', trigger: 'change' }],
        clientype: [{ required: true, message: '请选择客户类型', trigger: 'change' }],
      },
      // 组织选择树
      orgSelectParams: {
        clearable: true,
        placeholder: '请选择组织',
      },
      orgTreeParams: {
        'check-strictly': true,
        'default-expand-all': true,
        'expand-on-click-node': false,
        clickParent: true,
        data: this.orgTree,
        props: {
          children: 'children',
          label: 'orgname',
          disabled: 'disabled',
          value: 'id',
        },
      },
    };
  },
  watch: {
    orgTree() {
      if (this.$refs.orgTreeSelect) {
        this.$refs.orgTreeSelect.treeDataUpdateFun(this.orgTree);
      }
    },
    row() {
      if (this.$refs.addForm) {
        this.$refs.addForm.resetFields();
      }
      this.$nextTick(() => {
        this.addForm = {
          ...this.addForm,
          ...this.row,
          typenames: this.row.name ? [this.row.name] : [],
          strid: this.row.strid ? this.row.strid.split(',').map(Number) : [],
        };
      });
    },
  },
  methods: {
    // 选择语言
    handleLangChange() {
      this.addForm.checkLanguage.sort();
    },

    // 关闭
    close() {
      this.$emit('close');
    },

    // 提交添加角色或者修改角色
    submit() {
      this.$refs.addForm.validate(async (valid) => {
        if (valid) {
          let { typenames } = this.addForm;
          const { checkLanguage } = this.addForm;

          typenames = checkLanguage.map((k, i) => ({
            langid: k,
            text: typenames[i],
          }));

          const params = {
            ...this.addForm,
            typenames,
            strid: this.addForm.strid ? this.addForm.strid.join(',') : '',
          };

          delete params.checkLanguage;
          // "pid":"","num":"1","islive":"","clientype":"1","orgid":"2","type":"2","remarks":"","typenames":[{"langid":"0","text":"迷你"},{"langid":"1","text":"mini"}]}
          this.$emit('submit', params);
        }
      });
    },
  },
};
</script>
