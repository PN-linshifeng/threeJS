<template>
  <div class="app-container">
    <el-row style="margin-bottom:20px">
      <el-col :span="12">
        <el-form ref="searchData" :data="searchData" inline>
          <el-form-item prop="type">
            <el-select v-model="searchData.type" size="small">
              <el-option
                v-for="(value,key) in type"
                :key="key"
                :label="$t('type.'+ value[1])"
                :value="value[0]"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" icon="el-icon-search" size="small" @click="handleSearch">搜索</el-button>
          </el-form-item>
        </el-form>
      </el-col>
      <el-col class="fx-text-right" :span="12">
        <el-button type="primary" icon="el-icon-plus" size="small" @click="addEditFormShow()">添加类型</el-button>
      </el-col>
    </el-row>
    <el-row style="margin-bottom:20px">
      <el-col>
        <el-table
          v-loading="queryListLoading"
          :data="dataList.data"
          style="width: 100%;margin-bottom: 20px;"
          row-key="id"
        >
          <el-table-column prop="name" label="名称" />
          <el-table-column prop="type" label="类型">
            <template slot-scope="scope">{{ $t('type.'+type.get(scope.row.type)) }}</template>
          </el-table-column>
          <el-table-column prop="strid" label="文档类别" :formatter="stridFormat" />
          <el-table-column prop="num" label="序号" />
          <el-table-column prop="orgname" label="组织" />
          <el-table-column prop="islive" label="真实账户">
            <template slot-scope="scope">{{ scope.row.islive ? '是' : '否' }}</template>
          </el-table-column>
          <el-table-column prop="clientype" label="客户类型">
            <template
              slot-scope="scope"
            >{{ $te('type.'+clientType.get(scope.row.clientype))?$t('type.'+clientType.get(scope.row.clientype)):'' }}</template>
          </el-table-column>
          <el-table-column prop="remarks" label="备注" />
          <el-table-column label="操作" :width="270">
            <template slot-scope="scope" class="fx-text-right">
              <el-button
                type="primary"
                size="small"
                icon="el-icon-edit"
                @click="addEditFormShow(scope.row)"
              >修改</el-button>
              <el-button
                type="danger"
                size="small"
                icon="el-icon-delete"
                :loading="scope.row.deleteLoading"
                @click="handleDelete(scope.row.id, scope.$index)"
              >删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <pagination
          :total="dataList.total||0"
          :page.sync="dataList.pageNum"
          :limit.sync="dataList.pageSize"
          @pagination="pageChange"
        />
      </el-col>
    </el-row>
    <!--添加修改弹框-->
    <add-edit-form
      :visible="addEditFormVisible"
      :data-list="dataList"
      :org-tree="queryOrgListFormat"
      :row="editRow"
      :type="addEditType"
      :type-list="type"
      :doc-type-list="docTypeList"
      :submit-loading="addEditFormSubmitLoading"
      @close="addEditFormClose"
      @submit="addEditFormSubmit"
    />
  </div>
</template>
<script>
import { mapGetters } from 'vuex';
import { queryList, addType, updateType, deleteType, docType } from '@/api/systemType';
import { systemType, clientType } from '@/utils/type';
import Pagination from '@/components/Pagination';
import addEditForm from './components/addEditForm';

export default {
  components: {
    addEditForm,
    Pagination,
  },
  data() {
    return {
      // loading 参数
      queryListLoading: false,
      dataList: {},
      type: systemType,
      clientType,
      // 搜索表单
      searchForm: {},
      // 请求条件
      searchData: {
        ln: this.$ln,
        pageNum: 1,
        pageSize: 10,
        orderBy: 'createtime',
        sort: 'desc',
      },

      // 以下全部是添加修改
      addEditFormVisible: false,
      editRow: undefined,
      addEditType: 'add',
      addEditFormSubmitLoading: false,
      docTypeList: [],
    };
  },

  computed: {
    ...mapGetters({
      queryOrgListFormat: 'org/queryListFormat',
    }),
    filterClientType() {
      return Array.from(this.clientType).filter((k) => k[0] !== 4);
    },
  },

  created() {
    this.initRequest();
  },
  methods: {
    queryList() {
      const params = this.searchData;
      this.queryListLoading = true;
      queryList(params)
        .then((resp) => {
          this.dataList = resp;
          this.queryListLoading = false;
        })
        .catch(() => {
          this.queryListLoading = false;
        });
    },
    async initRequest() {
      const data = await docType({ ln: this.$ln });
      this.docTypeList = data;
      this.queryList();
    },
    // 分页
    pageChange({ page, limit }) {
      this.searchData.pageNum = page;
      this.searchData.pageSize = limit;
      this.queryList();
    },

    // 搜索
    handleSearch() {
      this.searchData = Object.assign(this.searchData, this.searchForm);
      this.queryList();
    },

    // 类型格式化
    typeFormat(row, column, cellValue) {
      const item = this.docTypeList.find((k) => k.id === cellValue);
      return (item && item.doctypename) || cellValue;
    },
    stridFormat(row, column, cellValue) {
      if (!cellValue) {
        return cellValue;
      }
      const arr = cellValue.split(',');
      const items = this.docTypeList.filter((k) => arr.indexOf(k.id.toString()) >= 0);
      const text = items.map((k) => k.doctypename);
      return text.join(',');
    },

    // 删除类型
    handleDelete(id, index) {
      this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
        type: 'warning',
      }).then(() => {
        const data = [...this.dataList.data];
        data[index].deleteLoading = true;
        this.dataList.data = [...data];
        deleteType({ id })
          .then(() => {
            this.queryList();
            this.$message({
              type: 'success',
              message: this.$t('config.deleteSuccess'),
            });
          })
          .catch(() => {
            this.$message({
              type: 'error',
              message: this.$t('config.deleteError'),
            });
          });
      });
    },

    // 添加活动
    /**
     * 以下是添加修改的全部方法
     */
    addEditFormClose() {
      this.addEditFormVisible = false;
      this.editRow = {};
    },
    addEditFormShow(row) {
      this.addEditFormVisible = true;
      if (row) {
        this.editRow = row;
        this.addEditType = 'edit';
      } else {
        this.addEditType = 'add';
      }
      if (this.queryOrgListFormat.length <= 0) {
        this.$store.dispatch('org/queryList', {
          ln: this.$ln,
        });
      }
    },
    addEditFormSubmit(params) {
      this.addEditFormSubmitLoading = true;

      let request;
      if (this.addEditType === 'add') {
        request = addType;
      } else {
        request = updateType;
      }
      request(params)
        .then(() => {
          this.addEditFormSubmitLoading = false;
          this.addEditFormClose();
          this.queryList();
        })
        .catch(() => {
          this.addEditFormSubmitLoading = false;
        });
    },
  },
};
</script>
