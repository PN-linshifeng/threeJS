<template>
  <editDialog :visible="visible" :submit-loading="submitLoading" @close="close" @submit="submit">
    <el-form ref="addForm" :model="addForm" :rules="addFormRules" label-width="120px">
      <el-form-item prop="username" label="用户名">
        <el-input v-model="addForm.username" value="88" />
      </el-form-item>
      <el-form-item prop="password" label="密码">
        <el-input v-model="addForm.password" placeholder="请输入8位以上含有大小写字母和数字" />
      </el-form-item>
      <el-form-item prop="nickname" label="昵称">
        <el-input v-model="addForm.nickname" />
      </el-form-item>
      <el-form-item prop="email" label="邮箱">
        <el-input v-model="addForm.email" />
      </el-form-item>

      <el-form-item prop="mtlogin" label="MT账户">
        <el-input v-model="addForm.mtlogin" />
      </el-form-item>

      <el-form-item label="手机号" prop="phone">
        <div class="fx-phone">
          <el-input v-model="addForm.phonecode" class="area" />
          <el-input v-model="addForm.phone" class="phone" />
        </div>
      </el-form-item>

      <el-form-item label="上级" prop="pid">
        <el-select v-model="addForm.pid" placeholder="请选择" style="min-width:100%">
          <el-option label="无上级" :value="0" />
          <el-option
            v-for="item in dataList"
            :key="item.id"
            :label="item.username"
            :value="item.id"
          />
        </el-select>
      </el-form-item>

      <el-form-item label="组织" prop="orgid">
        <el-tree-select
          ref="orgTreeSelect"
          key="orgTreeSelect"
          v-model="addForm.orgid"
          :select-params="orgSelectParams"
          :tree-params="orgTreeParams"
        />
      </el-form-item>

      <el-form-item label="角色" prop="roleid">
        <el-select v-model="addForm.roleid" placeholder="请选择">
          <el-option
            v-for="item in orgRoles"
            :key="item.id"
            :label="item.rolename"
            :value="item.id"
          />
        </el-select>
      </el-form-item>
    </el-form>
  </editDialog>
</template>
<script>
import editDialog from '@/components/EditDialog';

export default {
  components: { editDialog },
  props: {
    visible: { required: true, type: Boolean, default: false },
    submitLoading: { required: true, type: Boolean, default: false },
    type: { required: true, type: String, default: 'add' },
    dataList: {
      required: true,
      type: Array,
      default() {
        return [];
      },
    },
    roleList: {
      required: true,
      type: Array,
      default() {
        return [];
      },
    },
    row: {
      required: false,
      type: Object,
      default() {
        return {};
      },
    },
    orgTree: {
      required: false,
      type: Array,
      default() {
        return [];
      },
    },
  },
  data() {
    return {
      orgRoles: [], // 组织下的角色
      action: 'add', // 添加 edit修改
      // 添加修改Form
      addForm: {
        phonecode: '+86',
      },
      // 验证
      addFormRules: {
        roleid: [{ required: true, message: '不能为空', trigger: 'blur' }],
        orgid: [{ required: true, message: '请选择组织', trigger: 'change' }],
      },
      // 组织选择树
      orgSelectParams: {
        clearable: true,
        placeholder: '请选择组织',
      },
      orgTreeParams: {
        'check-strictly': true,
        'default-expand-all': true,
        'expand-on-click-node': false,
        clickParent: true,
        data: this.orgTree,
        props: {
          children: 'children',
          label: 'orgname',
          disabled: 'disabled',
          value: 'id',
        },
      },
    };
  },
  watch: {
    orgTree() {
      if (this.$refs.orgTreeSelect) {
        this.$refs.orgTreeSelect.treeDataUpdateFun(this.orgTree);
      }
    },
    row() {
      this.$nextTick(() => {
        this.addForm = { ...this.addForm, ...this.row };
      });
    },
    'addForm.orgid': function org(orgid) {
      this.orgRoles = this.roleList.filter((k) => k.orgid === orgid);
    },
    roleList() {
      this.orgRoles = this.roleList.filter((k) => k.orgid === this.addForm.orgid);
    },
  },

  methods: {
    // 关闭
    close() {
      this.$emit('close');
      this.$refs.addForm.resetFields();
    },

    // 提交
    submit() {
      this.$refs.addForm.validate(async (valid) => {
        if (valid) {
          this.$emit('submit', this.addForm);
        }
      });
    },
  },
};
</script>
