<template>
  <div class="app-container">
    <el-row style="margin-bottom:20px">
      <el-col :xs="24" :sm="12">
        <el-form ref="searchForm" :model="searchForm" inline>
          <el-form-item>
            <el-select v-model="searchForm.type">
              <el-option label="用户" value="0" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-input v-model="searchForm.value" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" icon="el-icon-search" @click="handleSearch">搜索</el-button>
          </el-form-item>
        </el-form>
      </el-col>
      <el-col :xs="24" :sm="12" class="fx-text-right">
        <el-button type="primary" icon="el-icon-plus" @click="addEditFormShow()">添加用户</el-button>
      </el-col>
    </el-row>

    <el-table
      v-loading="selectUserByParentLoading"
      :data="dataList.data||[]"
      style="width: 100%;margin-bottom: 20px;"
      row-key="id"
    >
      <el-table-column prop="username" label="用户名" :min-width="100" />
      <el-table-column prop="nickname" label="昵称" />
      <el-table-column prop="phone" label="手机" :formatter="formatPhone" />
      <el-table-column prop="email" label="电邮" />
      <el-table-column prop="mtlogin" label="MT登录账户" />
      <el-table-column prop="orgname" label="组织" />
      <el-table-column prop="rolename" label="角色名称" />
      <el-table-column label="操作" :width="270">
        <template slot-scope="scope">
          <el-button
            type="primary"
            size="small"
            icon="el-icon-edit"
            @click="addEditFormShow(scope.row)"
          >修改</el-button>

          <el-button
            type="danger"
            size="small"
            icon="el-icon-delete"
            :loading="scope.row.deleteLoading"
            @click="handleDelete(scope.row.userid)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <pagination
      :total="dataList.total||0"
      :page.sync="dataList.pageNum"
      :limit.sync="dataList.pageSize"
      @pagination="currentChange"
    />
    <!--添加修改弹框-->
    <add-edit-form
      :visible="addEditFormVisible"
      :data-list="dataList.data"
      :role-list="roleList"
      :org-tree="queryOrgListFormat"
      :row="editRow"
      :type="addEditType"
      :submit-loading="addEditFormSubmitLoading"
      @close="addEditFormClose"
      @submit="addEditFormSubmit"
    />
  </div>
</template>
<script>
/* eslint-disable object-curly-newline */
import { mapGetters, mapState } from 'vuex';
import { selectUserByParent, addUser, deleteUser, updateUser } from '@/api/systemUser';
import Pagination from '@/components/Pagination';
import addEditForm from './components/addEditForm';

export default {
  components: {
    addEditForm,
    Pagination,
  },
  data() {
    return {
      selectUserByParentLoading: false,
      searchParams: {
        ln: this.$ln,
        pageNum: 1,
        pageSize: 10,
        orderBy: 'createtime',
        sort: 'desc',
      },
      searchForm: {},
      dataList: {},

      // 以下全部是添加修改角色配置
      addEditFormVisible: false,
      editRow: {},
      addEditType: 'add',
      addEditFormSubmitLoading: false,
    };
  },
  computed: {
    ...mapState({
      roleList: (state) => state.role.queryList,
    }),
    ...mapGetters({
      queryListFormat: 'role/queryListFormat',
      queryOrgListFormat: 'org/queryListFormat',
      querymoduleListFormat: 'module/queryListFormat',
    }),
  },
  watch: {
    $route() {
      this.getDataList();
    },
  },
  mounted() {
    this.getDataList();
  },

  methods: {
    // 搜索
    handleSearch() {
      this.searchParams = {
        ...this.searchParams,
        ...this.searchForm,
        pageNum: 1,
      };
      this.$router.push({
        name: 'systemUser',
        query: this.searchParams,
      });
    },

    // 分页
    currentChange(page) {
      this.searchParams.pageNum = page.page;
      this.searchParams.pageSize = page.limit;
      this.$router.push({
        name: 'systemUser',
        query: this.searchParams,
      });
    },

    // 获取列表
    getDataList() {
      this.selectUserByParentLoading = true;
      const { query } = this.$route;
      this.searchParams = { ...this.searchParams, ...query };
      selectUserByParent(this.searchParams)
        .then((resp) => {
          this.dataList = resp;
          this.selectUserByParentLoading = false;
        })
        .catch(() => {
          this.selectUserByParentLoading = false;
        });
    },
    /**
     * @method 删除用户
     * @params {string} userid
     */
    handleDelete(userid) {
      this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      }).then(async () => {
        const { data } = this.dataList;
        const index = data.findIndex((k) => k.userid === userid);

        data[index].deleteLoading = true;
        this.$set(this.dataList, 'data', data);
        try {
          await deleteUser({ userid });
          this.$message.success('删除成功');
          data.splice(index, 1);
          this.getDataList();
        } catch (err) {
          data[index].deleteLoading = false;
          this.$message.error('删除失败');
        }
        this.$set(this.dataList, 'data', [...data]);
      });
    },

    /**
     * 以下是添加修改角色的全部方法
     */
    addEditFormClose() {
      this.editRow = {};
      this.addEditFormVisible = false;
    },
    addEditFormShow(row) {
      this.addEditFormVisible = true;
      if (row) {
        this.editRow = row;
        this.addEditType = 'edit';
      } else {
        this.addEditType = 'add';
      }
      if (this.queryOrgListFormat.length <= 0) {
        this.$store.dispatch('org/queryList', {
          ln: this.$ln,
        });
      }
      if (this.roleList.length <= 0) {
        this.$store.dispatch('role/queryList', {
          ln: this.$ln,
        });
      }
    },
    addEditFormSubmit(params) {
      this.addEditFormSubmitLoading = true;

      let request;
      if (this.addEditType === 'add') {
        request = addUser;
      } else {
        request = updateUser;
      }

      request(params)
        .then(() => {
          this.addEditFormSubmitLoading = false;
          this.addEditFormClose();
          this.queryList();
        })
        .catch(() => {
          this.addEditFormSubmitLoading = false;
        });
    },

    // formatPhone
    formatPhone(row) {
      return `${row.phonecode || ''} ${row.phone || ''}`;
    },
  },
};
</script>
