<template>
  <div class="app-container">
    <el-row style="margin-bottom:20px">
      <el-col>
        <el-button @click="handleAddRoleDialog">添加角色</el-button>
      </el-col>
    </el-row>

    <el-table
      v-loading="dataListLoading"
      :data="dataList"
      style="width: 100%;margin-bottom: 20px;"
      row-key="id"
      :tree-props="{children: 'children', hasChildren: 'hasChildren'}"
      default-expand-all
    >
      <el-table-column prop="rolename" label="角色名称" :min-width="100" />
      <el-table-column prop="orgname" label="组织" />
      <!-- <el-table-column prop="username" label="创建者" /> -->
      <el-table-column prop="idsname" label="名称" />
      <!-- <el-table-column prop="strid" label="strid" /> -->
      <!-- <el-table-column prop="fieldid" label="字段" /> -->
      <el-table-column prop="common" label="公开" />
      <el-table-column prop="createtime" label="创建时间" :formatter="time" />
      <el-table-column prop="updatetime" label="修改时间" :formatter="time" />
      <el-table-column label="操作" :width="270">
        <template slot-scope="scope">
          <el-button
            type="primary"
            size="small"
            icon="el-icon-edit"
            @click="handleUpdataRoleDialog(scope.row)"
          >修改</el-button>
          <el-button
            type="primary"
            size="small"
            icon="el-icon-user"
            :loading="scope.row.queryRoleByIdLoading"
            @click="handleRole(scope.row)"
          >权限</el-button>
          <el-button type="danger" size="small" icon="el-icon-delete">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--权限弹框-->
    <el-dialog :visible.sync="roleDialogVisible" title="选择权限" width="580px">
      <el-form
        ref="roleDialog"
        :model="authorityForm"
        label-width="120px"
        style="max-height:300px; overflow: auto;"
      >
        <el-tree
          ref="modeleTree"
          v-loading="moduleListLoading"
          :data="queryModuleDataListFormat"
          show-checkbox
          node-key="id"
          default-expand-all
          :props="{label:'name'}"
          :expand-on-click-node="false"
        >
          <!-- <span slot-scope="{ node, data }" class="custom-tree-node">
            <span>{{ node.label }}</span>
            <span>
              <el-button type="text" size="mini" @click="() => append(data)">Append</el-button>
              <el-button type="text" size="mini" @click="() => remove(node, data)">Delete</el-button>
            </span>
          </span>-->
        </el-tree>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="roleDialogVisible = false">取 消</el-button>
        <el-button type="primary" :loading="addRightByRoleLoading" @click="handleSubmit">确 定</el-button>
      </span>
    </el-dialog>
    <!--添加修改弹框-->
    <el-dialog :visible.sync="addRoleDialogVisible" width="580px">
      <el-form ref="addForm" :model="addForm" :rules="addFormRules" label-width="120px">
        <el-form-item :label="$t('config.language')" prop="checkLanguage">
          <el-checkbox-group v-model="addForm.checkLanguage">
            <el-checkbox
              v-for="(value, name) in $langList"
              :key="name"
              :label="name"
            >{{ value.text }}</el-checkbox>
          </el-checkbox-group>
        </el-form-item>
        <el-form-item
          v-for="(k,index) of addForm.checkLanguage"
          :key="k"
          :label="$langList[k].text"
          prop="rolenames"
        >
          <el-input v-model="addForm.rolenames[index]" placeholder="请输入内容" />
        </el-form-item>
        <el-form-item label="组织" prop="orgid">
          <el-tree-select
            ref="orgTreeSelect"
            key="orgTreeSelect"
            v-model="addForm.orgid"
            :select-params="orgSelectParams"
            :tree-params="orgTreeParams"
          />
        </el-form-item>
        <el-form-item label="下级角色" prop="strids">
          <el-select v-model="addForm.strids" multiple placeholder="请选择" style="min-width:100%">
            <el-option
              v-for="item in dataList"
              :key="item.id"
              :label="item.rolename"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="是否公开">
          <el-radio v-model="addForm.common" label="0">否</el-radio>
          <el-radio v-model="addForm.common" label="2">是</el-radio>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="addRoleDialogVisible = false">取 消</el-button>
        <el-button type="primary" :loading="addRoleLoading" @click="handleSubmitRole">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
/* eslint-disable object-curly-newline */
import { mapState, mapGetters } from 'vuex';
import { queryRightByRole, addRightByRole } from '@/api/role';

export default {
  data() {
    return {
      // loading 参数
      addRoleLoading: false,
      addRightByRoleLoading: false,
      // 以下是选择权限
      roleDialogVisible: false,
      authorityForm: {
        roleId: '',
        rightlist: [],
      },
      // 以下全部是添加修改角色配置
      addRoleDialogVisible: false,
      // 组织选择树
      orgSelectParams: {
        clearable: true,
        placeholder: '请选择组织',
      },
      orgTreeParams: {
        'check-strictly': true,
        'default-expand-all': true,
        'expand-on-click-node': false,
        clickParent: true,
        // filterable: true,
        data: [],
        props: {
          children: 'children',
          label: 'orgname',
          disabled: 'disabled',
          value: 'id',
        },
      },
      // 添加修改Form
      addForm: {
        language: this.$langList,
        checkLanguage: ['0'],
        id: '', // 修改携带id
        action: 'add', // 添加 edit修改
        pid: '',
        strids: [],
        common: '0',
        orgid: '',
        rolenames: [],
      },
      addFormRules: {
        checkLanguage: [
          {
            type: 'array',
            required: true,
            message: '请至少选择一个语言',
            trigger: 'change',
          },
        ],
        rolenames: [{ required: true, message: '不能为空', trigger: 'blur' }],
        orgid: [{ required: true, message: '请选择组织', trigger: 'change' }],
        strids: [
          {
            type: 'array',
            required: true,
            message: '请选择下级',
            trigger: 'change',
          },
        ],
      },
    };
  },

  computed: {
    ...mapState({
      dataList: state => state.role.queryList,
      dataListLoading: state => state.role.queryListLoading,
      moduleList: state => state.moduleData.queryList,
      moduleListLoading: state => state.moduleData.queryListLoading,
    }),
    ...mapGetters({
      queryListFormat: 'role/queryListFormat',
      queryOrgListFormat: 'org/queryListFormat',
      queryModuleDataListFormat: 'moduleData/queryListFormat',
    }),
    lang() {
      return this.$i18n.locale;
    },
  },

  created() {
    this.queryList();
  },
  methods: {
    queryList() {
      this.$store.dispatch('role/queryList', {
        ln: this.$ln,
      });
    },

    // 时间格式化
    time(row, column, cellValue) {
      return this.$moment(cellValue).format('YYYY-MM-DD');
    },
    /**
     * 以下是选择权限的全部方法
     */
    // 查询权限
    async handleRole(row) {
      const { id } = row;
      const ln = this.$ln;
      this.authorityForm.roleId = id;
      this.roleDialogVisible = true;
      if (this.queryModuleDataListFormat.length <= 0) {
        await this.$store.dispatch('moduleData/queryList', {
          ln,
        });
      }
      if (this.$refs.modeleTree) {
        this.$refs.modeleTree.setCheckedKeys([]);
      }
      const roleID = await queryRightByRole({
        roleids: id,
        ln,
      });
      const tree = roleID.map(k => k.id);
      this.$refs.modeleTree.setCheckedKeys(tree);
    },

    // 提交选择权限
    async handleSubmit() {
      const checkID = this.$refs.modeleTree.getCheckedKeys();
      let items = this.moduleList.filter(k => {
        const index = checkID.indexOf(k.id) >= 0;
        return index;
      });
      items = items.map(k => ({
        moduleid: k.id.toString(),
        funcid: k.funcid.toString(),
      }));
      this.addRightByRoleLoading = true;

      addRightByRole({
        rightlist: JSON.stringify(items),
        roleid: this.authorityForm.roleId,
      })
        .then(() => {
          this.roleDialogVisible = false;
          this.addRightByRoleLoading = false;
          this.$message.success('设置成功！');
        })
        .catch(() => {
          this.$message.error('设置失败！');
          this.addRightByRoleLoading = false;
        });
    },
    /**
     * 以下是添加修改角色的全部方法
     */
    // 打开添加角色
    handleAddRoleDialog() {
      this.addRoleDialogVisible = !this.addRoleDialogVisible;
      if (this.queryOrgListFormat.length <= 0) {
        this.$store
          .dispatch('org/queryList', {
            ln: this.$ln,
          })
          .then(() => {
            this.$refs.orgTreeSelect.treeDataUpdateFun(this.queryOrgListFormat);
          });
      } else if (this.$refs.orgTreeSelect) {
        this.$refs.orgTreeSelect.treeDataUpdateFun(this.queryOrgListFormat);
      }
      this.orgTreeParams.data = this.queryOrgListFormat;
      // 重置表单
      this.addForm = {
        language: this.$langList,
        checkLanguage: ['0'],
        action: 'add',
        strids: [],
        common: '0',
        orgid: '',
        rolenames: [],
      };
      if (this.$refs.addForm) {
        this.$refs.addForm.resetFields();
      }
    },
    // 打开修改角色
    handleUpdataRoleDialog(row) {
      const { id, strids, orgid, common, rolename, fieldid } = row;

      this.addForm.action = 'edit';
      this.addForm.id = id;
      this.addForm.fieldid = fieldid;
      this.addForm.rolenames = [rolename];
      this.addForm.strids = strids && strids.split(',').map(Number);
      this.addForm.orgid = orgid;
      this.addForm.common = common.toString();
      this.addRoleDialogVisible = !this.addRoleDialogVisible;
      if (this.queryOrgListFormat.length <= 0) {
        this.$store.dispatch('org/queryList', {
          ln: this.$ln,
        });
      }
    },
    // 提交添加角色或者修改角色
    handleSubmitRole() {
      this.$refs.addForm.validate(async valid => {
        if (valid) {
          // {"id":"1","strids":"2,3","common":"1","orgid":"1","rolenames":[{"langid":"0","text":"客户经理"},{"langid":"1","text":"accmanger"}]}
          //
          let { strids, rolenames } = this.addForm;
          const {
            common,
            orgid,
            checkLanguage,
            id,
            action,
            fieldid,
          } = this.addForm;
          strids = strids.join();
          rolenames = checkLanguage.map((k, i) => ({
            langid: k,
            text: rolenames[i],
          }));
          // rolenames = JSON.stringify(rolenames);
          const type = action === 'add' ? 'role/addRole' : 'role/updateRole';
          const params = {
            strids,
            common,
            orgid,
            rolenames,
          };
          if (id) {
            params.id = id;
            params.fieldid = fieldid;
          }
          this.addRoleLoading = true;
          try {
            await this.$store.dispatch(type, {
              params: JSON.stringify(params),
            });
            this.addRoleDialogVisible = false;
            this.queryList();
          } finally {
            this.addRoleLoading = false;
          }
        }
      });
    },
  },
};
</script>
<style>
.custom-tree-node {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 8px;
}
</style>
