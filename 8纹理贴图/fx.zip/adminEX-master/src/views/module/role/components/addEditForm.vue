<template>
  <edit-dialog
    :visible="visible"
    width="580px"
    :submit-loading="submitLoading"
    @close="handleClose"
    @submit="handleSubmit"
  >
    <el-form ref="addForm" :model="addForm" :rules="addFormRules" label-width="120px">
      <el-form-item :label="$t('config.language')" prop="checkLanguage">
        <el-checkbox-group v-model="addForm.checkLanguage" @change="handleLangChange">
          <el-checkbox v-for="k of $langList" :key="k.code" :label="k.ln">{{ k.text }}</el-checkbox>
        </el-checkbox-group>
      </el-form-item>
      <template v-for="k of $langList">
        <el-form-item
          v-if="addForm.checkLanguage.includes(k.ln)"
          :key="k.code"
          :label="k.text"
          prop="rolenames"
        >
          <el-input v-model="addForm.rolenames[k.ln]" placeholder="请输入内容" />
        </el-form-item>
      </template>

      <el-form-item label="组织" prop="orgid">
        <el-tree-select
          ref="orgTreeSelect"
          key="orgTreeSelect"
          v-model="addForm.orgid"
          :select-params="orgSelectParams"
          :tree-params="orgTreeParams"
        />
      </el-form-item>
      <el-form-item label="下级角色" prop="strids">
        <el-select v-model="addForm.strids" multiple placeholder="请选择" style="min-width:100%">
          <el-option
            v-for="item in roleList"
            :key="item.id"
            :label="item.rolename"
            :value="item.id"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="是否公开">
        <el-radio v-model="addForm.common" :label="0">否</el-radio>
        <el-radio v-model="addForm.common" :label="1">是</el-radio>
      </el-form-item>
    </el-form>
  </edit-dialog>
</template>
<script>
import editDialog from '@/components/EditDialog';

export default {
  components: { editDialog },
  props: {
    visible: { required: true, type: Boolean, default: false },
    submitLoading: { required: true, type: Boolean, default: false },
    type: { required: true, type: String, default: 'add' },
    dataList: {
      required: true,
      type: Array,
      default() {
        return [];
      },
    },
    row: {
      required: false,
      type: Object,
      default() {
        return {};
      },
    },
    orgTree: {
      required: false,
      type: Array,
      default() {
        return [];
      },
    },
  },
  data() {
    return {
      roleList: [],
      // 添加修改Form
      addForm: {
        checkLanguage: [0],
        id: '', // 修改携带id
        pid: '',
        strids: [],
        common: 0,
        orgid: '',
        rolenames: {},
      },
      // 验证
      addFormRules: {
        checkLanguage: [
          {
            type: 'array',
            required: true,
            message: '请至少选择一个语言',
            trigger: 'change',
          },
        ],
        rolenames: [{ required: true, message: '不能为空', trigger: 'blur' }],
        orgid: [{ required: true, message: '请选择组织', trigger: 'change' }],
        strids: [
          {
            type: 'array',
            required: false,
            message: '请选择下级',
            trigger: 'change',
          },
        ],
      },
      // 组织选择树
      orgSelectParams: {
        clearable: true,
        placeholder: '请选择组织',
      },
      orgTreeParams: {
        'check-strictly': true,
        'default-expand-all': true,
        'expand-on-click-node': false,
        clickParent: true,
        data: this.orgTree,
        props: {
          children: 'children',
          label: 'orgname',
          disabled: 'disabled',
          value: 'id',
        },
      },
    };
  },
  watch: {
    orgTree() {
      if (this.$refs.orgTreeSelect) {
        this.$refs.orgTreeSelect.treeDataUpdateFun(this.orgTree);
      }
    },
    'addForm.orgid': function orgid(val) {
      this.roleList = this.dataList.filter((k) => k.orgid === val);
    },
    row() {
      if (this.visible) {
        this.$nextTick(() => {
          const { id, strids, orgid = '', common = 0, rolename, fieldid } = this.row;
          this.addForm = {
            ...this.addForm,
            id,
            fieldid,
            rolenames: { [this.$ln]: rolename },
            strids: strids ? strids.split(',').map(Number) : [],
            orgid,
            common,
          };
        });
      }
    },
  },
  methods: {
    // 选择语言
    handleLangChange() {
      this.addForm.checkLanguage.sort();
    },
    // 关闭
    handleClose() {
      this.$emit('close');
      this.$refs.addForm.resetFields();
    },

    // 提交添加角色或者修改角色
    handleSubmit() {
      this.$refs.addForm.validate((valid) => {
        if (valid) {
          let { strids, rolenames } = this.addForm;
          const { common, orgid, checkLanguage, id, fieldid } = this.addForm;
          strids = strids.join();
          rolenames = checkLanguage.map((k) => ({
            langid: k,
            text: rolenames[k],
          }));

          const params = {
            strids,
            common,
            orgid,
            rolenames,
          };
          if (id) {
            params.id = id;
            params.fieldid = fieldid;
          }
          // {"strids":"2,32","common":"2","orgid":4,"rolenames":[{"langid":"0","text":"dg"}]}
          this.$emit('submit', params);
        }
      });
    },
  },
};
</script>
