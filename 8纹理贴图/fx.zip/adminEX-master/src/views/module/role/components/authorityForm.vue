<template>
  <el-dialog :visible="visible" title="选择权限" width="580px" :before-close="handleClose">
    <el-form ref="form" :model="form" label-width="120px" style="max-height:300px; overflow: auto;">
      <el-tree
        ref="modeleTree"
        v-loading="moduleListLoading"
        :data="moduleListFormat"
        show-checkbox
        node-key="id"
        default-expand-all
        :default-checked-keys="checkedKeys"
        :props="{label:'name'}"
        :expand-on-click-node="false"
      />
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose">取 消</el-button>
      <el-button type="primary" :loading="submitLoading" @click="handleSubmit">确 定</el-button>
    </span>
  </el-dialog>
</template>
<script>
export default {
  props: {
    visible: { required: true, type: Boolean, default: false },
    moduleListLoading: { required: false, type: Boolean, default: false },
    submitLoading: { required: true, type: Boolean, default: false },
    moduleList: {
      required: true,
      type: Array,
      default() {
        return [];
      },
    },
    moduleListFormat: {
      required: true,
      type: Array,
      default() {
        return [];
      },
    },
    checkedKeys: {
      required: true,
      type: Array,
      default() {
        return [];
      },
    },
  },
  data() {
    return {
      form: {
        roleId: '',
        rightlist: [],
      },
    };
  },
  watch: {
    checkedKeys() {
      if (this.$refs.modeleTree) {
        this.$refs.modeleTree.setCheckedKeys(this.checkedKeys);
      }
    },
  },
  methods: {
    // 关闭
    handleClose() {
      this.$emit('close');
      this.$refs.form.resetFields();
    },
    handleSubmit() {
      const checkID = this.$refs.modeleTree.getCheckedKeys();
      let items = this.moduleList.filter(k => {
        const index = checkID.indexOf(k.id) >= 0;
        return index;
      });
      items = items.map(k => ({
        moduleid: k.id.toString(),
        funcid: k.funcid.toString(),
      }));
      this.addRightByRoleLoading = true;
      this.$emit('submit', items);
    },
  },
};
</script>
