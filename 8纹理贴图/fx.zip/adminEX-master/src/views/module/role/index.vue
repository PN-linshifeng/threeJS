<template>
  <div class="app-container">
    <el-row style="margin-bottom:20px">
      <el-col>
        <el-button @click="addEditFormShow()">添加角色</el-button>
      </el-col>
    </el-row>

    <el-table
      v-loading="dataListLoading"
      :data="dataList"
      style="width: 100%;margin-bottom: 20px;"
      row-key="id"
      :tree-props="{ children: 'children', hasChildren: 'hasChildren' }"
      default-expand-all
    >
      <el-table-column prop="rolename" label="角色名称" :min-width="100" />
      <el-table-column prop="orgname" label="组织" />
      <!-- <el-table-column prop="username" label="创建者" /> -->
      <el-table-column prop="idsname" label="名称" />
      <!-- <el-table-column prop="strid" label="strid" /> -->
      <!-- <el-table-column prop="fieldid" label="字段" /> -->
      <el-table-column prop="common" label="公开" />
      <el-table-column prop="createtime" label="创建时间" :formatter="time" />
      <el-table-column prop="updatetime" label="修改时间" :formatter="time" />
      <el-table-column label="操作" :width="270">
        <template slot-scope="scope">
          <el-button
            type="primary"
            size="mini"
            icon="el-icon-edit"
            @click="addEditFormShow(scope.row)"
          >修改</el-button>
          <el-button
            type="primary"
            size="mini"
            icon="el-icon-user"
            :loading="scope.row.queryRoleByIdLoading"
            @click="handleRole(scope.row)"
          >权限</el-button>
          <el-button
            type="danger"
            size="mini"
            icon="el-icon-delete"
            :loading="scope.row.deleteLoading"
            @click="handleDeleteRole(scope.row)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--权限弹框-->
    <authority-form
      :visible="authorityFormVisible"
      :module-list="moduleList"
      :module-list-format="querymoduleListFormat"
      :submit-loading="authorityFormSubmitLoading"
      :checked-keys="checkedKeys"
      @close="authorityFormClose"
      @submit="authorityFormSubmit"
    />
    <!--添加修改弹框-->
    <add-edit-form
      :visible="addEditFormVisible"
      :data-list="dataList"
      :org-tree="queryOrgListFormat"
      :row="editRow"
      :type="addEditType"
      :submit-loading="addEditFormSubmitLoading"
      @close="addEditFormClose"
      @submit="addEditFormSubmit"
    />
  </div>
</template>
<script>
/* eslint-disable object-curly-newline */
import { mapState, mapGetters } from 'vuex';
import { queryRightByRole, addRightByRole } from '@/api/role';
import addEditForm from './components/addEditForm';
import authorityForm from './components/authorityForm';

export default {
  components: {
    addEditForm,
    authorityForm,
  },
  data() {
    return {
      // loading 参数
      addRightByRoleLoading: false,

      // 以下是选择权限
      authorityFormID: '',
      authorityFormVisible: false,
      checkedKeys: [], // 默认选中的
      authorityFormSubmitLoading: false,

      // 以下全部是添加修改角色配置
      addEditFormVisible: false,
      editRow: undefined,
      addEditType: 'add',
      addEditFormSubmitLoading: false,
    };
  },

  computed: {
    ...mapState({
      dataList: (state) => state.role.queryList,
      dataListLoading: (state) => state.role.queryListLoading,
      moduleList: (state) => state.module.queryList,
      moduleListLoading: (state) => state.module.queryListLoading,
    }),
    ...mapGetters({
      queryListFormat: 'role/queryListFormat',
      queryOrgListFormat: 'org/queryListFormat',
      querymoduleListFormat: 'module/queryListFormat',
    }),
    lang() {
      return this.$i18n.locale;
    },
  },

  created() {
    this.queryList();
  },
  methods: {
    queryList() {
      this.$store.dispatch('role/queryList', {
        ln: this.$ln,
      });
    },

    // 时间格式化
    time(row, column, cellValue) {
      return this.$moment(cellValue).format('YYYY-MM-DD');
    },

    /**
     * 以下是选择权限的全部方法
     */
    // 关闭权限窗口
    authorityFormClose() {
      this.authorityFormVisible = false;
    },
    // 查询权限
    async handleRole(row) {
      const { id } = row;
      const ln = this.$ln;
      if (this.querymoduleListFormat.length <= 0) {
        await this.$store.dispatch('module/queryList', {
          ln,
        });
      }
      const roleID = await queryRightByRole({
        roleids: id,
        ln,
      });
      this.authorityFormID = id;
      this.checkedKeys = roleID.map((k) => k.id);
      this.authorityFormVisible = true;
    },

    // 提交选择权限
    authorityFormSubmit(data) {
      this.authorityFormSubmitLoading = true;
      addRightByRole({
        rightlist: JSON.stringify(data),
        roleid: this.authorityFormID,
      })
        .then(() => {
          this.authorityFormSubmitLoading = false;
          this.authorityFormVisible = false;
          this.$message.success('设置成功！');
        })
        .catch(() => {
          this.$message.error('设置失败！');
          this.authorityFormSubmitLoading = false;
        });
    },
    /**
     * 以下是添加修改角色的全部方法
     */
    addEditFormClose() {
      this.addEditFormVisible = false;
      this.editRow = {};
    },
    addEditFormShow(row) {
      this.addEditFormVisible = true;
      if (row) {
        this.editRow = row;
        this.addEditType = 'edit';
      } else {
        this.addEditType = 'add';
      }
      if (this.queryOrgListFormat.length <= 0) {
        this.$store.dispatch('org/queryList', {
          ln: this.$ln,
        });
      }
    },
    addEditFormSubmit(params) {
      this.addEditFormSubmitLoading = true;

      let type = '';
      if (this.addEditType === 'add') {
        type = 'role/addRole';
      } else {
        type = 'role/updateRole';
      }

      this.$store
        .dispatch(type, {
          params: JSON.stringify(params),
        })
        .then(() => {
          //
          this.addEditFormSubmitLoading = false;
          this.queryList();
          this.$message.success('操作成功');
          this.addEditFormClose();
        })
        .catch(() => {
          this.addEditFormSubmitLoading = false;
          this.$message.error('操作失败');
        });
    },
    // 删除角色
    handleDeleteRole(row) {
      this.$confirm('此操作将删除数据，是否继续？', '提示')
        .then(() => {
          const { id } = row;
          this.$store.dispatch('role/deleteRole', { id }).then(() => {
            this.$message({
              type: 'success',
              message: this.$t('config.deleteSuccess'),
            }).catch(() => {
              this.$message({
                type: 'error',
                message: this.$t('config.deleteError'),
              });
            });
          });
        })
        .catch(() => {
          this.$message.warning('取消此操作');
        });
    },
  },
};
</script>
<style>
.custom-tree-node {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 8px;
}
</style>
