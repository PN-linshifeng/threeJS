<template>
  <editDialog :visible="visible" :submit-loading="submitLoading" @close="close" @submit="submit">
    <el-form ref="addForm" :model="addForm" :role="addFormRules" label-width="100px">
      <el-form-item label="上级：" prop="pid">
        <el-tree-select
          ref="treeSelect"
          v-model="addForm.pid"
          :select-params="selectParams"
          :tree-params="treeParams"
        />
      </el-form-item>
      <el-form-item label="类型：">
        <el-radio v-for="v of type" :key="v[0]" v-model="addForm.type" :label="v[0]">{{ v[1] }}</el-radio>
      </el-form-item>
      <el-form-item :label="$t('config.language')" prop="checkLanguage">
        <el-checkbox-group v-model="addForm.checkLanguage" @change="handleLangChange">
          <el-checkbox v-for="k of $langList" :key="k.code" :label="k.ln">{{ k.text }}</el-checkbox>
        </el-checkbox-group>
      </el-form-item>
      <template v-for="k of $langList">
        <el-form-item
          v-if="addForm.checkLanguage.includes(k.ln)"
          :key="k.code"
          :label="k.text"
          prop="modulenames"
        >
          <el-input v-model="addForm.modulenames[k.ln]" placeholder="请输入内容" />
        </el-form-item>
      </template>
      <el-form-item label="地址：" prop="url">
        <el-input v-model="addForm.url" size="small" />
      </el-form-item>
    </el-form>
  </editDialog>
</template>
<script>
import editDialog from '@/components/EditDialog';

export default {
  components: { editDialog },
  props: {
    visible: { required: true, type: Boolean, default: false },
    submitLoading: { required: true, type: Boolean, default: false },
    row: {
      required: false,
      type: Object,
      default() {
        return {};
      },
    },
    dataList: {
      required: true,
      type: Array,
    },
    type: {
      required: true,
      type: Map,
    },
  },
  data() {
    return {
      addForm: {
        checkLanguage: [this.$ln],
        modulenames: {},
        type: 1,
        funcid: 0,
      },
      addFormRules: {},

      // tree
      selectParams: {
        // multiple: true,
        clearable: true,
        placeholder: '请输入内容',
      },
      treeParams: {
        clickParent: true,
        // filterable: true,
        'check-strictly': true,
        'default-expand-all': true,
        'expand-on-click-node': false,
        data: this.dataList,
        props: {
          children: 'children',
          label: 'name',
          disabled: 'disabled',
          value: 'id',
        },
      },
    };
  },
  watch: {
    dataList() {
      const map = [...this.dataList];
      map.unshift({
        name: '无上级',
        id: 0,
        value: 0,
        pid: 0,
      });

      if (this.$refs.treeSelect) {
        this.$refs.treeSelect.treeDataUpdateFun(map);
      } else {
        this.treeParams.data = map;
      }
    },
    row() {
      if (this.$refs.addForm) {
        this.$refs.addForm.resetFields();
      }
      this.$nextTick(() => {
        const { type = 1, name, id, fieldid, funcid = 0, pid = 0, url } = this.row;
        this.addForm = {
          ...this.addForm,
          type,
          funcid,
          id,
          pid,
          fieldid,
          url,
          modulenames: name ? { [this.$ln]: name } : {},
        };
      });
    },
  },
  methods: {
    // 选择语言
    handleLangChange() {
      this.addForm.checkLanguage.sort();
    },
    // 关闭
    close() {
      this.$emit('close');
      this.$refs.addForm.resetFields();
    },
    // 提交添加角色或者修改角色
    submit() {
      this.$refs.addForm.validate(async (valid) => {
        if (valid) {
          let { modulenames } = this.addForm;
          modulenames = this.addForm.checkLanguage.map((k) => ({
            langid: k,
            text: modulenames[k],
          }));

          const params = {
            ...this.addForm,
            modulenames,
          };

          // {"checkLanguage":["0"],"modulenames":[{"langid":"0","text":"发送到发"}],"type":"1","funcid":"0","pid":"65","url":"发"}
          this.$emit('submit', params);
        }
      });
    },
  },
};
</script>
