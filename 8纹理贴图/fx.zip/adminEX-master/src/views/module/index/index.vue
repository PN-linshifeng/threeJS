<template>
  <div class="app-container">
    <el-row style="margin-bottom:20px">
      <el-col>
        <el-button @click="addEditFormShow()">新增功能</el-button>
      </el-col>
    </el-row>
    <el-table
      :data="queryListFormat"
      style="width: 100%;margin-bottom: 20px;"
      row-key="id"
      :tree-props="{children: 'children', hasChildren: 'hasChildren'}"
    >
      <el-table-column prop="id" label="ID" :width="80" />
      <el-table-column prop="name" label="功能名称" />
      <el-table-column label="类型">
        <template slot-scope="scope">
          <span>{{ type.get(scope.row.type) }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="url" label="地址" />
      <el-table-column prop="func" label="接口" />
      <el-table-column prop="createtime" label="创建时间" :formatter="time" />
      <el-table-column prop="updatetime" label="修改时间" :formatter="time" />
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            type="primary"
            size="mini"
            icon="el-icon-edit"
            @click="addEditFormShow(scope.row)"
          >修改</el-button>
          <el-button
            type="danger"
            size="mini"
            icon="el-icon-delete"
            :loading="scope.row.deleteLoading"
            @click="handleDelete(scope.row)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--添加修改弹框-->
    <add-edit-form
      :visible="addEditFormVisible"
      :data-list="queryListFormat"
      :row="editRow"
      :type="type"
      :submit-loading="addEditFormSubmitLoading"
      @close="addEditFormClose"
      @submit="addEditFormSubmit"
    />
  </div>
</template>
<script>
import { mapState, mapGetters } from 'vuex';

import addEditForm from './components/addEditForm';

const type = new Map([
  [1, '目录'],
  [2, '子菜单'],
  [3, '功能'],
]);

export default {
  name: 'ModuleList',
  components: { addEditForm },
  data() {
    return {
      type,
      dialogVisible: false,
      dialogTitle: '修改',
      dialogForm: {
        action: 'edit',
        id: '',
        pid: undefined,
        type: 1,
        url: '',
        funcid: '',
        fieldid: 1,
        modulenames: [],
        checkLanguage: ['0'],
      },
      dialogFormRole: {},

      /**
       * 以下是添加修改弹框参数
       */
      addEditFormVisible: false,
      editRow: {},
      addEditType: 'add',
      addEditFormSubmitLoading: false,
    };
  },

  computed: {
    ...mapState({
      dataList: (state) => state.module.queryList,
      addEditLoading: (state) => state.module.addEditLoading,
    }),
    ...mapGetters({
      queryListFormat: 'module/queryListFormat',
    }),
  },
  watch: {},
  mounted() {},

  created() {
    this.queryList();
  },
  methods: {
    queryList() {
      this.$store.dispatch('module/queryList', { ln: this.$ln }).then((resp) => {
        this.$store.dispatch('user/resetAside', resp);
      });
    },
    // 时间格式化
    time(row, column, cellValue) {
      return this.$moment(cellValue).format('YYYY-MM-DD');
    },

    // 删除模块
    handleDelete(row) {
      this.$confirm('此操作将删除数据，是否继续？', '提示')
        .then(() => {
          const { id } = row;
          this.$store.dispatch('module/deleteModule', { id }).then(() => {
            this.$store.dispatch('user/deleteAside', { id });
          });
        })
        .catch(() => {
          this.$message.warning('取消此操作');
        });
    },
    /**
     * 以下是添加和修改方法
     */
    addEditFormClose() {
      this.addEditFormVisible = false;
      this.editRow = {};
    },
    addEditFormShow(row) {
      this.addEditFormVisible = true;
      if (row) {
        this.editRow = row;
        this.addEditType = 'edit';
      } else {
        this.editRow = {};
        this.addEditType = 'add';
      }
    },
    // 提交修改或添加
    addEditFormSubmit(params) {
      this.addEditFormSubmitLoading = true;
      let type = '';
      if (this.addEditType === 'add') {
        type = 'module/addModule';
      } else {
        type = 'module/updateModule';
      }
      this.$store
        .dispatch(type, params)
        .then(() => {
          this.$message.success('成功');
          this.queryList();
          this.addEditFormSubmitLoading = false;
          this.addEditFormClose();
          // this.$store.dispatch('user/editAside', data);
        })
        .catch(() => {
          this.addEditFormSubmitLoading = false;
          this.$message.error('失败');
        });
    },
  },
};
</script>
