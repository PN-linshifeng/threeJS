<template>
  <div class="app-container">
    <el-row style="margin-bottom:20px">
      <el-col>
        <el-button @click="handleAddRoleDialog">新增功能</el-button>
      </el-col>
    </el-row>
    <el-table
      :data="queryListFormat"
      style="width: 100%;margin-bottom: 20px;"
      row-key="id"
      :tree-props="{children: 'children', hasChildren: 'hasChildren'}"
    >
      <el-table-column prop="id" label="ID" :width="80" />
      <el-table-column prop="name" label="功能名称" />
      <el-table-column prop="type" label="类型" />
      <el-table-column prop="url" label="地址" />
      <el-table-column prop="fieldid" label="接口" />
      <el-table-column prop="createtime" label="创建时间" :formatter="time" />
      <el-table-column prop="updatetime" label="修改时间" :formatter="time" />
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            type="primary"
            size="small"
            icon="el-icon-edit"
            @click="handleEdit(scope.row)"
          >修改</el-button>
          <el-button
            type="danger"
            size="small"
            icon="el-icon-delete"
            :loading="scope.row.deleteLoading"
            @click="handleDelete(scope.row)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-dialog :title="dialogTitle" :visible="dialogVisible" width="560px">
      <el-form ref="dialogForm" :model="dialogForm" :role="dialogFormRole" label-width="80px">
        <el-form-item label="上级：" prop="pid">
          <el-tree-select
            ref="treeSelect"
            v-model="dialogForm.pid"
            :select-params="selectParams"
            :tree-params="treeParams"
          />
        </el-form-item>
        <el-form-item label="类型：">
          <el-radio v-for="v of type" :key="v[0]" v-model="dialogForm.type" :label="v[0]">{{ v[1] }}</el-radio>
        </el-form-item>
        <el-form-item :label="$t('config.language')" prop="checkLanguage">
          <el-checkbox-group v-model="dialogForm.checkLanguage">
            <el-checkbox
              v-for="(value, name) in $langList"
              :key="name"
              :label="name"
            >{{ value.text }}</el-checkbox>
          </el-checkbox-group>
        </el-form-item>
        <template v-for="(value, name) in $langList">
          <el-form-item
            v-if="dialogForm.checkLanguage.includes(name)"
            :key="name"
            :label="$langList[name].text"
            prop="modulenames"
          >
            <el-input v-model="dialogForm.modulenames[name]" placeholder="请输入内容" />
          </el-form-item>
        </template>
        <el-form-item label="地址：" prop="url">
          <el-input v-model="dialogForm.url" size="small" />
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" :loading="addEditLoading" @click="handleSubmit">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import { mapState, mapGetters } from 'vuex';
import toTree from '@/utils/treeTotree';

const type = new Map([
  ['1', '目录'],
  ['2', '子菜单'],
  ['3', '功能'],
]);

export default {
  data() {
    return {
      type,
      dialogVisible: false,
      dialogTitle: '修改',
      dialogForm: {
        action: 'edit',
        id: '',
        pid: undefined,
        type: '1',
        url: '',
        funcid: '',
        fieldid: 1,
        modulenames: [],
        checkLanguage: ['0'],
      },
      dialogFormRole: {},

      // tree
      selectParams: {
        // multiple: true,
        clearable: true,
        placeholder: '请输入内容',
      },
      treeParams: {
        clickParent: true,
        // filterable: true,
        'check-strictly': true,
        'default-expand-all': true,
        'expand-on-click-node': false,
        data: [],
        props: {
          children: 'children',
          label: 'title',
          disabled: 'disabled',
          value: 'id',
        },
      },
    };
  },

  computed: {
    ...mapState({
      dataList: state => state.moduleData.queryList,
      addEditLoading: state => state.moduleData.addEditLoading,
    }),
    ...mapGetters({
      queryListFormat: 'moduleData/queryListFormat',
    }),
  },
  watch: {
    dataList() {
      const tree = this.dataList.map(k => ({
        title: k.name,
        value: k.id,
        id: k.id,
        pid: k.pid,
      }));
      const map = toTree(tree);
      map.unshift({
        title: '无上级',
        id: 0,
        value: 0,
        pid: 0,
      });

      if (this.$refs.treeSelect) {
        this.$refs.treeSelect.treeDataUpdateFun(map);
      } else {
        this.treeParams.data = map;
      }
    },
  },
  mounted() {},

  created() {
    this.queryList();
  },
  methods: {
    queryList() {
      this.$store.dispatch('moduleData/queryList', { ln: this.$ln });
      // .then(data => {
      //   const tree = data.map(k => ({
      //     title: k.name,
      //     value: k.id,
      //     id: k.id,
      //     pid: k.pid,
      //   }));
      //   const map = toTree(tree);
      //   map.unshift({
      //     title: '无上级',
      //     id: 0,
      //     value: 0,
      //     pid: 0,
      //   });
      //   this.treeParams.data = map;
      // });
    },
    // 时间格式化
    time(row, column, cellValue) {
      return this.$moment(cellValue).format('YYYY-MM-DD');
    },

    // 删除模块
    handleDelete(row) {
      const { id } = row;
      this.$store.dispatch('moduleData/deleteModule', { id });
    },
    /**
     * 以下是添加和修改方法
     */
    // 打开添加窗口
    handleAddRoleDialog() {
      this.dialogVisible = true;
      this.dialogTitle = '添加';
      this.dialogForm = {
        action: 'add',
        id: '',
        pid: '0',
        type: '1',
        url: '',
        funcid: '',
        fieldid: 1,
        modulenames: [],
        checkLanguage: ['0'],
      };
    },
    // 打开修改窗口
    handleEdit(record) {
      this.dialogVisible = true;
      this.dialogTitle = '修改';
      this.dialogForm = {
        ...this.dialogForm,
        ...record,
        type: record.type.toString(),
        modulenames: { [this.$ln]: record.name },
        action: 'edit',
      };
    },
    // 提交修改或添加
    handleSubmit() {
      const modulenames = this.dialogForm.checkLanguage.map(k => {
        const langid = k;
        const text = this.dialogForm.modulenames[k];
        return { langid, text };
      });
      const data = {
        modulenames,
        pid: this.dialogForm.pid,
        type: this.dialogForm.type,
        url: this.dialogForm.url,
        funcid: 0,
      };
      let action = 'moduleData/addModule';

      if (this.dialogForm.action === 'edit') {
        data.id = this.dialogForm.id;
        data.fieldid = this.dialogForm.fieldid;
        action = 'moduleData/updateModule';
      }

      this.$store
        .dispatch(action, { params: JSON.stringify(data) })
        .then(() => {
          this.queryList();
          this.$refs.dialogForm.resetFields();
          this.dialogVisible = false;
          this.$message.success(`${this.dialogTitle}成功`);
          this.$store.dispatch('user/aside', data);
        })
        .catch(() => {
          this.$message.error(`${this.dialogTitle}失败`);
        });
    },
  },
};
</script>
