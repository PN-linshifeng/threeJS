<template>
  <div class="app-container">
    <el-table
      :data="dataList"
      style="width: 100%;margin-bottom: 20px;"
      row-key="id"
      :tree-props="{children: 'children', hasChildren: 'hasChildren'}"
      default-expand-all
    >
      <el-table-column prop="orgname" label="组织" :min-width="100" />
      <el-table-column prop="username" label="创建者" />
      <el-table-column prop="description" label="描述" />
      <el-table-column prop="type" label="类型" />
      <el-table-column prop="fieldid" label="字段" />
      <el-table-column prop="status" label="状态" />
      <el-table-column prop="common" label="公共" />
      <el-table-column prop="strid" label="strid" />
      <el-table-column prop="createtime" label="创建时间" :formatter="time" />
      <el-table-column prop="updatetime" label="修改时间" :formatter="time" />
      <el-table-column label="操作" :width="180">
        <template slot-scope="scope">
          <el-button
            type="primary"
            size="small"
            icon="el-icon-edit"
            @click="handleEdit(scope.row)"
          >修改</el-button>

          <el-button type="danger" size="small" icon="el-icon-delete">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>
<script>
import { mapState } from 'vuex';
import toTree from '@/utils/treeTotree';

export default {
  data() {
    return {};
  },

  computed: {
    ...mapState({
      dataList: state => {
        const tree = state.org.queryList.map(k => ({
          key: `key${k.id}`,
          ...k,
        }));
        const map = toTree(tree);
        return map;
      },
    }),
  },
  mounted() {},

  created() {
    this.queryList();
  },
  methods: {
    queryList() {
      this.$store.dispatch('org/queryList', { ln: 0 }).then(data => {
        const tree = data.map(k => ({
          title: k.name,
          value: k.id,
          id: k.id,
          pid: k.pid,
        }));
        const map = toTree(tree);
        this.treeParams.data = map;
      });
    },

    // 时间格式化
    time(row, column, cellValue) {
      return this.$moment(cellValue).format('YYYY-MM-DD');
    },
  },
};
</script>
