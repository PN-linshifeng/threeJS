<template>
  <div class="app-container">
    <el-row>
      <el-col class="fx-text-right" :span="24">
        <el-button type="primary" icon="el-icon-plus" size="small" @click="addEditFormShow()">添加</el-button>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="24">
        <el-table
          v-loading="dataLoading"
          :data="dataList"
          style="width: 100%;margin-bottom: 20px;"
          row-key="id"
          :tree-props="{children: 'children', hasChildren: 'hasChildren'}"
          default-expand-all
        >
          <el-table-column prop="orgname" label="组织" :min-width="100" />
          <el-table-column prop="username" label="创建者" />
          <el-table-column prop="description" label="描述" />
          <el-table-column prop="type" label="类型">
            <template slot-scope="scope">{{ type.get(scope.row.type)||'无' }}</template>
          </el-table-column>
          <!-- <el-table-column prop="fieldid" label="字段" />
          <el-table-column prop="status" label="状态" />-->
          <el-table-column prop="common" label="公共">
            <template slot-scope="scope">{{ scope.row.common===1?'公开':'隐藏' }}</template>
          </el-table-column>
          <!-- <el-table-column prop="strid" label="strid" /> -->
          <el-table-column prop="createtime" label="创建时间" :formatter="time" />
          <el-table-column prop="updatetime" label="修改时间" :formatter="time" />
          <el-table-column label="操作" :width="180">
            <template slot-scope="scope">
              <el-button
                type="primary"
                size="mini"
                icon="el-icon-edit"
                @click="addEditFormShow(scope.row)"
              >修改</el-button>

              <el-button
                type="danger"
                size="mini"
                icon="el-icon-delete"
                :loading="scope.row.deleteLoading"
                @click="handleDelete(scope.row.id)"
              >删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-col>
    </el-row>
    <!--添加修改弹框-->
    <add-edit-form
      :visible="addEditFormVisible"
      :data-list="dataList"
      :row="editRow"
      :org-tree="dataList"
      :type="type"
      :submit-loading="addEditFormSubmitLoading"
      @close="addEditFormClose"
      @submit="addEditFormSubmit"
    />
  </div>
</template>
<script>
import { mapState, mapGetters } from 'vuex';
// import toTree from '@/utils/treeTotree';
import addEditForm from './components/addEditForm';

export default {
  name: 'Org',
  components: { addEditForm },
  data() {
    return {
      type: new Map([
        [0, '无'],
        [1, '业务公司'],
        [2, '客服公司'],
        [3, '技术公司'],
        [4, 'ib公司'],
      ]),
      /**
       * 以下是添加修改弹框参数
       */
      addEditFormVisible: false,
      editRow: {},
      addEditType: 'add',
      addEditFormSubmitLoading: false,
    };
  },

  computed: {
    ...mapState({
      dataLoading: (state) => state.org.queryListLoading,
    }),
    ...mapGetters({
      dataList: 'org/queryListFormat',
    }),
  },

  mounted() {},
  created() {
    this.queryList();
  },
  methods: {
    queryList() {
      this.$store.dispatch('org/queryList', { ln: this.$ln });
    },

    // 时间格式化
    time(row, column, cellValue) {
      return this.$moment(cellValue).format('YYYY-MM-DD');
    },

    // 刪除
    handleDelete(id) {
      this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(async () => {
          await this.$store.dispatch('org/deleteOrg', { id });
          this.$message({
            type: 'success',
            message: '删除成功!',
          });
          this.queryList();
        })
        .catch(() => {});
    },

    /**
     * 以下是添加修改方法
     */
    addEditFormClose() {
      this.addEditFormVisible = false;
      this.editRow = {};
    },
    addEditFormShow(row) {
      this.addEditFormVisible = true;
      if (row) {
        this.editRow = row;
        this.addEditType = 'edit';
      } else {
        this.editRow = {};
        this.addEditType = 'add';
      }
    },
    addEditFormSubmit(params) {
      this.addEditFormSubmitLoading = true;

      let type = '';
      if (this.addEditType === 'add') {
        type = 'org/addOrg';
      } else {
        type = 'org/updateOrg';
      }
      this.$store
        .dispatch(type, params)
        .then(() => {
          this.addEditFormSubmitLoading = false;
          this.addEditFormVisible = false;
          this.queryList();
        })
        .catch(() => {
          this.addEditFormSubmitLoading = false;
        });
    },
  },
};
</script>
