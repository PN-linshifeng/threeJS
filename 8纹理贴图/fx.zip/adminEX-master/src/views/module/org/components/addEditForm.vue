<template>
  <editDialog :visible="visible" :submit-loading="submitLoading" @close="close" @submit="submit">
    <el-form ref="addForm" :model="addForm" :rules="addFormRules" label-width="120px">
      <el-form-item :label="$t('config.language')" prop="checkLanguage">
        <el-checkbox-group v-model="addForm.checkLanguage" @change="handleLangChange">
          <el-checkbox v-for="k of $langList" :key="k.code" :label="k.ln">{{ k.text }}</el-checkbox>
        </el-checkbox-group>
      </el-form-item>
      <template v-for="k of $langList">
        <el-form-item
          v-if="addForm.checkLanguage.includes(k.ln)"
          :key="k.code"
          :label="k.text"
          prop="orgnames"
        >
          <el-input v-model="addForm.orgnames[k.ln]" placeholder="请输入内容" />
        </el-form-item>
      </template>

      <el-form-item label="上级" prop="pid">
        <el-tree-select
          ref="orgTreeSelect"
          key="orgTreeSelect"
          v-model="addForm.pid"
          :select-params="orgSelectParams"
          :tree-params="orgTreeParams"
        />
      </el-form-item>
      <el-form-item label="类型" prop="type">
        <el-select v-model="addForm.type">
          <el-option v-for="(value,key) of type" :key="key" :label="value[1]" :value="value[0]" />
        </el-select>
      </el-form-item>
      <el-form-item label="是否公开" prop="common">
        <el-radio v-model="addForm.common" :label="0">否</el-radio>
        <el-radio v-model="addForm.common" :label="1">是</el-radio>
      </el-form-item>
      <el-form-item label="备注" prop="description">
        <el-input v-model="addForm.description" type="textarea" />
      </el-form-item>
    </el-form>
  </editDialog>
</template>
<script>
import editDialog from '@/components/EditDialog';

export default {
  components: { editDialog },
  props: {
    visible: { required: true, type: Boolean, default: false },
    submitLoading: { required: true, type: Boolean, default: false },
    row: {
      required: false,
      type: Object,
      default() {
        return {};
      },
    },
    orgTree: {
      required: true,
      type: Array,
    },
    type: {
      required: true,
      type: Map,
    },
  },
  data() {
    return {
      addForm: {
        checkLanguage: [this.$ln],
        orgnames: {},
        common: 0,
        description: '',
      },
      addFormRules: {},

      // 组织选择树
      orgSelectParams: {
        clearable: true,
        placeholder: '请选择上级',
      },
      orgTreeParams: {
        'check-strictly': true,
        'default-expand-all': true,
        'expand-on-click-node': false,
        clickParent: true,
        data: this.orgTree,
        props: {
          children: 'children',
          label: 'orgname',
          disabled: 'disabled',
          value: 'id',
        },
      },
    };
  },
  watch: {
    orgTree() {
      if (this.$refs.orgTreeSelect) {
        this.$refs.orgTreeSelect.treeDataUpdateFun(this.orgTree);
      } else {
        this.orgTreeParams.data = this.orgTree;
      }
    },
    row() {
      if (this.$refs.addForm) {
        this.$refs.addForm.resetFields();
      }
      this.$nextTick(() => {
        const { common = 0, description, type, pid, orgname, id, fieldid } = this.row;
        this.addForm = {
          ...this.addForm,
          common,
          description,
          type,
          pid,
          id,
          fieldid,
          orgnames: orgname ? { [this.$ln]: orgname } : {},
        };
      });
    },
  },
  methods: {
    // 选择语言
    handleLangChange() {
      this.addForm.checkLanguage.sort();
    },
    // 关闭
    close() {
      this.$emit('close');
      this.$refs.addForm.resetFields();
    },
    // 提交
    submit() {
      this.$refs.addForm.validate(async (valid) => {
        if (valid) {
          let { orgnames } = this.addForm;
          orgnames = this.addForm.checkLanguage.map((k) => ({
            langid: k,
            text: orgnames[k],
          }));

          const params = {
            ...this.addForm,
            orgnames,
          };
          // {"strids":"2,32","common":"2","orgid":4,"rolenames":[{"langid":"0","text":"dg"}]}
          this.$emit('submit', params);
        }
      });
    },
  },
};
</script>
