<template>
  <el-dialog :visible="visible" width="580px" :before-close="handleClose">
    <el-form ref="addForm" :model="addForm" :rules="addFormRules" label-width="120px">
      <el-form-item :label="$t('config.language')" prop="checkLanguage">
        <el-checkbox-group v-model="addForm.checkLanguage">
          <el-checkbox v-for="(value, name) in $langList" :key="name" :label="name">{{ value.text }}</el-checkbox>
        </el-checkbox-group>
      </el-form-item>
      <el-form-item
        v-for="(k, index) of addForm.checkLanguage"
        :key="k"
        :label="$langList[k].text"
        prop="rolenames"
      >
        <el-input v-model="addForm.rolenames[index]" placeholder="请输入内容" />
      </el-form-item>
      <el-form-item label="组织" prop="orgid">
        <el-tree-select
          ref="orgTreeSelect"
          key="orgTreeSelect"
          v-model="addForm.orgid"
          :select-params="orgSelectParams"
          :tree-params="orgTreeParams"
        />
      </el-form-item>
      <el-form-item label="下级角色" prop="strids">
        <el-select v-model="addForm.strids" multiple placeholder="请选择" style="min-width:100%">
          <el-option
            v-for="item in dataList"
            :key="item.id"
            :label="item.rolename"
            :value="item.id"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="是否公开">
        <el-radio v-model="addForm.common" label="0">否</el-radio>
        <el-radio v-model="addForm.common" label="2">是</el-radio>
      </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose">取 消</el-button>
      <el-button type="primary" :loading="submitLoading" @click="handleSubmitRole">确 定</el-button>
    </span>
  </el-dialog>
</template>
<script>
export default {
  props: {
    visible: { required: true, type: Boolean, default: false },
    submitLoading: { required: true, type: Boolean, default: false },
    type: { required: true, type: String, default: 'add' },
    dataList: {
      required: true,
      type: Array,
      default() {
        return [];
      },
    },
    row: {
      required: false,
      type: Object,
      default() {
        return {};
      },
    },
    orgTree: {
      required: false,
      type: Array,
      default() {
        return [];
      },
    },
  },
  data() {
    return {
      // 添加修改Form
      addForm: {
        language: this.$langList,
        checkLanguage: ['0'],
        id: '', // 修改携带id
        action: 'add', // 添加 edit修改
        pid: '',
        strids: [],
        common: '0',
        orgid: '',
        rolenames: [],
      },
      // 验证
      addFormRules: {
        checkLanguage: [
          {
            type: 'array',
            required: true,
            message: '请至少选择一个语言',
            trigger: 'change',
          },
        ],
        rolenames: [{ required: true, message: '不能为空', trigger: 'blur' }],
        orgid: [{ required: true, message: '请选择组织', trigger: 'change' }],
        strids: [
          {
            type: 'array',
            required: true,
            message: '请选择下级',
            trigger: 'change',
          },
        ],
      },
      // 组织选择树
      orgSelectParams: {
        clearable: true,
        placeholder: '请选择组织',
      },
      orgTreeParams: {
        'check-strictly': true,
        'default-expand-all': true,
        'expand-on-click-node': false,
        clickParent: true,
        data: this.orgTree,
        props: {
          children: 'children',
          label: 'orgname',
          disabled: 'disabled',
          value: 'id',
        },
      },
    };
  },
  watch: {
    orgTree() {
      if (this.$refs.orgTreeSelect) {
        this.$refs.orgTreeSelect.treeDataUpdateFun(this.orgTree);
      }
    },
    row() {
      if (this.row) {
        const { id, strids, orgid, common, rolename, fieldid } = this.row;
        this.addForm.action = 'edit';
        this.addForm.id = id;
        this.addForm.fieldid = fieldid;
        this.addForm.rolenames = [rolename];
        this.addForm.strids = strids && strids.split(',').map(Number);
        this.addForm.orgid = orgid;
        this.addForm.common = common.toString();
      }
    },
  },
  methods: {
    // 关闭
    handleClose() {
      this.$emit('close');
      this.addForm = {
        language: this.$langList,
        checkLanguage: ['0'],
        action: 'add',
        strids: [],
        common: '0',
        orgid: '',
        rolenames: [],
      };
      this.$refs.addForm.resetFields();
    },

    // 提交添加角色或者修改角色
    handleSubmitRole() {
      this.$refs.addForm.validate(async valid => {
        if (valid) {
          let { strids, rolenames } = this.addForm;
          const { common, orgid, checkLanguage, id, fieldid } = this.addForm;
          strids = strids.join();
          rolenames = checkLanguage.map((k, i) => ({
            langid: k,
            text: rolenames[i],
          }));

          const params = {
            strids,
            common,
            orgid,
            rolenames,
          };
          if (id) {
            params.id = id;
            params.fieldid = fieldid;
          }
          this.$emit('submit', params);
        }
      });
    },
  },
};
</script>
