<template>
  <div class="app-container">
    <el-row style="margin-bottom:20px">
      <el-col>
        <el-button @click="addEditFormShow()">添加活动</el-button>
      </el-col>
    </el-row>
    <el-row style="margin-bottom:20px">
      <el-col>
        <el-table
          v-loading="queryListLoading"
          :data="dataList.data"
          style="width: 100%;margin-bottom: 20px;"
          row-key="id"
        >
          <el-table-column prop="domain" label="活动网址" />
          <el-table-column prop="description" label="描述" />
          <el-table-column prop="lang" :label="$t('config.language')">
            <template slot-scope="scope">{{ $langList[scope.row.lang].text }}</template>
          </el-table-column>
          <el-table-column prop="createtime" label="创建时间" :formatter="time" />
          <el-table-column prop="updatetime" label="更新时间" :formatter="time" />
          <el-table-column label="操作" :width="270">
            <template slot-scope>
              <el-button type="primary" size="small" icon="el-icon-edit">修改</el-button>
              <el-button type="danger" size="small" icon="el-icon-delete">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <el-pagination
          background
          layout="prev, pager, next"
          :total="dataList.total"
          :current-page="dataList.pageNum"
          :page-size="dataList.pageSize"
          class="fx-text-right"
          @current-change="pageChange"
        />
      </el-col>
    </el-row>
  </div>
</template>
<script>
import { queryList } from '@/api/ADLandPage';

export default {
  components: {},
  data() {
    return {
      // loading 参数
      queryListLoading: false,
      dataList: {},
      searchForm: {
        ln: this.$ln,
        pageNum: 10,
        pageSize: 10,
        orderBy: 'createtime',
        sort: 'desc',
      },
    };
  },

  computed: {},

  created() {
    this.queryList();
  },
  methods: {
    queryList() {
      this.queryListLoading = true;
      queryList(this.searchForm)
        .then((resp) => {
          this.dataList = resp;
          this.queryListLoading = false;
        })
        .catch(() => {
          this.queryListLoading = false;
        });
    },
    // 分页
    pageChange(page) {
      this.searchForm.pageNum = page;
      this.queryList();
    },

    // 时间格式化
    time(row, column, cellValue) {
      return this.$moment(cellValue).format('YYYY-MM-DD');
    },

    // 添加活动
    addEditFormShow() {},
  },
};
</script>
