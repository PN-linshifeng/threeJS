<template>
  <div class="register-page container">
    <el-form
      ref="registerForm"
      :model="registerForm"
      :rules="registerFormRules"
      label-width="150px"
      class="register-form"
    >
      <el-form-item :label="$t('email.label')" prop="username">
        <el-input v-model="registerForm.username" :placeholder="$t('email.placeholder')" />
      </el-form-item>
      <el-form-item :label="$t('password.label')" prop="password">
        <el-input
          v-model="registerForm.password"
          show-password
          :placeholder="$t('password.placeholder')"
        />
      </el-form-item>
      <el-form-item :label="$t('password2.label')" prop="password2">
        <el-input
          v-model="registerForm.password2"
          show-password
          :placeholder="$t('password2.placeholder')"
        />
      </el-form-item>
      <el-form-item :label="$t('telephone.label')" prop="phone">
        <div class="fx-phone">
          <el-input v-model="registerForm.phonecode" class="area" />
          <el-input
            v-model="registerForm.phone"
            class="phone"
            :placeholder="$t('telephone.placeholder')"
          />
        </div>
      </el-form-item>
      <el-form-item :label="$t('country.label')" prop="country" class="country">
        <el-select v-model="registerForm.country">
          <el-option
            v-for="k of countrySelect"
            :key="k.code"
            :label="k.name"
            :value="k.code"
            :status="k.status"
            :disabled="!k.status"
          />
        </el-select>
      </el-form-item>
      <el-form-item :label="$t('userType')" prop="regtype">
        <el-select v-model="registerForm.regtype" disabled>
          <el-option :label="$t('DA')" value="1" />
          <el-option :label="$t('LA')" value="2" />
          <el-option :label="$t('IB')" value="3" />
          <el-option :label="$t('MM')" value="5" />
          <el-option :label="$t('others')" value="99" />
        </el-select>
      </el-form-item>
      <el-form-item :label="$t('affiliate')">
        <el-input v-model="registerForm.agentcode" />
      </el-form-item>
      <el-form-item prop="checkbox">
        <p v-for="(k,index) of registerForm.agreements" :key="k.id">
          <el-checkbox
            v-model="registerForm.agreements[index].result"
          >{{ registerForm.agreements[index].name }}</el-checkbox>
        </p>

        <p class="fx-tip-info">
          <i class="el-icon-info" />
          <span>
            <i18n path="tip.temp">
              <a slot="a" href="/#1" target="_blank">{{ $t('tip.a') }}</a>
            </i18n>
          </span>
        </p>
      </el-form-item>
      <el-form-item>
        <el-button
          type="primary"
          size="largn"
          :loading="registerLoading"
          class="submit"
          @click="submit"
        >{{ $t('submit') }}</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
import { email, password, phone } from '@/utils/regex';
import { judgeCountry, getAgreementList, register } from '@/api/register';
import lang from './lang';

export default {
  data() {
    const checkEmail = (rule, value, callback) => {
      if (!email.test(value)) {
        callback(new Error(this.$t('email.rule')));
      } else {
        callback();
      }
    };
    const checkPassword = (rule, value, callback) => {
      if (!password.test(value)) {
        callback(new Error(this.$t('password.rule')));
      } else {
        callback();
      }
    };
    const checkPassword2 = (rule, value, callback) => {
      if (value !== this.registerForm.password) {
        callback(new Error(this.$t('password2.rule')));
      } else {
        callback();
      }
    };
    const checkTelephone = (rule, value, callback) => {
      if (!phone.test(value) || this.registerForm.phonecode === '') {
        callback(new Error(this.$t('telephone.rule')));
      } else {
        callback();
      }
    };
    const checkCountry = (rule, value, callback) => {
      const status = this.countrySelect.find((k) => {
        const flag = k.value === value && k.status === '0';
        return flag;
      });
      if (status) {
        callback(new Error(this.$t('country.rule')));
      } else {
        callback();
      }
    };

    return {
      registerLoading: false,
      countrySelect: [],
      countryMarginBottom: 80,
      registerForm: {
        ln: this.$ln,
        username: '',
        password: '',
        password2: '',
        phone: '',
        phonecode: '',
        regtype: '2', //  0-demo  1-live  2-ib
        country: undefined,
        // agreement1: '',
        // isOptOut: '',

        loginway: '1', // 1，邮箱注册 ，  2   手机注册
        currency: 'USD',
        // username: 'wxpwxp',
        // rating: 'A',

        agentcode: '', // 介绍人
        acctype: '1', // 账户类型
        agreements: [],
      },
      registerFormRules: {
        username: [
          {
            required: 'true',
            message: this.$t('email.required'),
            trigger: 'blur',
          },
          { validator: checkEmail, trigger: 'blur' },
        ],
        password: [
          {
            required: 'true',
            message: this.$t('password.required'),
            trigger: 'blur',
          },
          { validator: checkPassword, trigger: 'blur' },
        ],
        password2: [
          {
            required: 'true',
            message: this.$t('password2.required'),
            trigger: 'blur',
          },
          { validator: checkPassword2, trigger: 'blur' },
        ],
        phone: [
          {
            required: 'true',
            message: this.$t('telephone.required'),
            trigger: 'blur',
          },
          { validator: checkTelephone, trigger: 'blur' },
        ],
        country: [
          {
            required: 'true',
            message: this.$t('country.required'),
            trigger: 'blur',
          },
          { validator: checkCountry, trigger: 'change' },
        ],
      },
    };
  },
  i18n: {
    // `i18n` 选项，为组件设置语言环境信息
    messages: lang,
  },
  mounted() {
    const { utm_affiliatecode: utmAffiliatecode, regtype } = this.$route.query;
    this.registerForm.agentcode = utmAffiliatecode || this.registerForm.agentcode;
    this.registerForm.regtype = regtype || this.registerForm.regtype;
    this.initRequest();
  },
  methods: {
    // 获取城市和注册协议
    initRequest() {
      judgeCountry({ ln: this.$ln }).then((data) => {
        const {
          country: { code, phonecode },
          countrys,
        } = data;
        this.registerForm.country = code;
        this.registerForm.phonecode = phonecode;
        this.countrySelect = countrys;
      });
      getAgreementList({
        orgid: 1,
        step: 1,
        ln: this.$ln,
      }).then((data) => {
        this.registerForm.agreements = data;
      });
    },

    submit() {
      const agreements = [];
      // eslint-disable-next-line no-restricted-syntax
      for (const k of this.registerForm.agreements) {
        agreements.push({ agreementid: k.id, result: k.result ? 1 : 0 });
        if (k.obligatory && !k.result) {
          return;
        }
      }
      // agreements = JSON.stringify(agreements);
      const params = { ...this.registerForm, agreements };

      this.$refs.registerForm.validate((valid) => {
        if (valid) {
          this.registerLoading = true;
          register({ params })
            .then(() => {
              this.registerLoading = false;
              // this.$refs.registerForm.resetFields();
              this.$message({
                type: 'success',
                message: this.$t('success'),
              });
            })
            .catch(() => {
              this.registerLoading = false;
              this.$message({
                type: 'errer',
                message: this.$t('fail'),
              });
            });
        }
      });
    },
  },
};
</script>
<style lang="scss">
.register-form {
  margin: 0 auto;
  max-width: 550px;
  p {
    margin: 0px 0px 10px;
    line-height: 1.6;
  }
  .tip-info {
  }
  .country .el-form-item__error {
    position: static;
  }
  .submit {
    width: 100%;
  }
}
</style>
