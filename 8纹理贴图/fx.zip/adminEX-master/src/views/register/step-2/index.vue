<template>
  <div class="register-page container">
    <el-form
      ref="registerForm"
      :model="registerForm"
      :rules="registerFormRules"
      label-width="150px"
      class="register-form"
    >
      <div class="item-title">注册信息</div>
      <el-form-item :label="$t('email.label')" prop="username">
        <el-input v-model="registerForm.username" :placeholder="$t('email.placeholder')" />
      </el-form-item>

      <el-form-item :label="$t('telephone.label')" prop="phone">
        <div class="fx-phone">
          <el-input v-model="registerForm.phonecode" class="area" />
          <el-input
            v-model="registerForm.phone"
            class="phone"
            :placeholder="$t('telephone.placeholder')"
          />
        </div>
      </el-form-item>

      <div class="item-title">账户配置</div>
      <el-form-item :label="$t('currency.label')" prop="currency">
        <el-input v-model="registerForm.currency" :placeholder="$t('currency.rule')" />
        <!-- <el-select v-model="registerForm.currency">
          <el-option v-for="k of currencySelect" :key="k.code" :label="k.name" :value="k.code" />
        </el-select>-->
      </el-form-item>

      <el-form-item :label="$t('accountType.label')" prop="accountType">
        <el-select v-model="registerForm.accountType">
          <el-option v-for="k of accountTypeSelect" :key="k.id" :label="k.label" :value="k.id" />
        </el-select>
      </el-form-item>
      <el-form-item :label="$t('platform.label')" prop="platform">
        <el-select v-model="registerForm.platform">
          <el-option label="MT4" value="4" />
          <el-option label="MT5" value="5" />
        </el-select>
      </el-form-item>

      <div class="item-title">申请人基本信息</div>
      <el-form-item :label="$t('nationality.label')" prop="nationality">
        <el-select v-model="registerForm.nationality" filterable>
          <el-option v-for="k of countrySelect" :key="k.code" :label="k.name" :value="k.code" />
        </el-select>
      </el-form-item>
      <el-form-item :label="$t('title.label')">
        <el-select v-model="registerForm.title">
          <el-option
            v-for="k of $t('title.select')"
            :key="k.value"
            :label="k.label"
            :value="k.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item :label="$t('surName.label')" prop="surName">
        <el-input v-model="registerForm.surName" :placeholder="$t('surName.rule')" />
      </el-form-item>
      <el-form-item :label="$t('lastName.label')" prop="lastName">
        <el-input v-model="registerForm.lastName" :placeholder="$t('lastName.rule')" />
      </el-form-item>

      <el-form-item :label="$t('nickName.label')" prop="nickName">
        <el-input v-model="registerForm.nickName" :placeholder="$t('nickName.rule')" />
      </el-form-item>
      <el-form-item :label="$t('identityType.label')" prop="identityType">
        <el-radio
          v-for="k of $t('identityType.data')"
          :key="k.value"
          v-model="registerForm.identityType"
          :label="k.value"
          @change="handleChange"
        >{{ k.label }}</el-radio>
      </el-form-item>

      <el-form-item v-if="identityOthersVisible" prop="identityOthers">
        <el-input v-model="registerForm.identityOthers" :placeholder="$t('identityOthers.rule')" />
      </el-form-item>
      <el-form-item prop="identity" :label="$t('identity.label')">
        <el-input v-model="registerForm.identity" :placeholder="$t('identity.rule')" />
      </el-form-item>
      <el-form-item :label="$t('birthcountry.label')">
        <el-select v-model="registerForm.birthcountry" filterable>
          <el-option v-for="k of countrySelect" :key="k.code" :label="k.name" :value="k.code" />
        </el-select>
      </el-form-item>
      <el-form-item :label="$t('birthday.label')" prop="birthday">
        <el-date-picker
          v-model="registerForm.birthday"
          type="date"
          :placeholder="$t('birthday.rule')"
        />
      </el-form-item>
      <el-form-item :label="$t('country.label')" required>
        <el-select v-model="registerForm.country" disabled>
          <el-option v-for="k of countrySelect" :key="k.code" :label="k.name" :value="k.code" />
        </el-select>
      </el-form-item>
      <el-form-item prop="city" :label="$t('city.label')">
        <el-input v-model="registerForm.city" :placeholder="$t('city.rule')" />
      </el-form-item>
      <el-form-item prop="address" :label="$t('address.label')">
        <el-input v-model="registerForm.address" :placeholder="$t('address.rule')" />
      </el-form-item>
      <el-form-item prop="addressEn" :label="$t('addressEn.label')">
        <el-input v-model="registerForm.addressEn" :placeholder="$t('addressEn.rule')" />
      </el-form-item>
      <el-form-item prop="addressDate" :label="$t('addressDate.label')">
        <el-input v-model="registerForm.addressDate" :placeholder="$t('addressDate.rule')" />
      </el-form-item>
      <el-form-item :label="$t('homePhone.label')" prop="homePhone">
        <el-input v-model="registerForm.homePhone" :placeholder="$t('homePhone.rule')" />
      </el-form-item>

      <!-- 遍历问答 -->
      <template v-for="(k,i) of questionnaireList">
        <div :key="k.id" class="item-title">{{ k.text }}</div>
        <template v-if="k.children && k.category===1">
          <div v-for="(kk) of k.children" :key="kk.id">
            <el-form-item
              v-if="!kk.hidden"
              :label="kk.text"
              :prop="'answers.'+kk.id"
              :rules="[{required:true,message: (kk.type===3?'请填写':'请选择')+''+kk.text,trigger: kk.type===3?'blur':'change'}]"
            >
              <!-- select -->
              <el-select
                v-if="kk.type===1&&kk.children"
                v-model="registerForm.answers[kk.id]"
                @change="handleHidden($event,i)"
              >
                <el-option
                  v-for="kkk of kk.children"
                  :key="kkk.id"
                  :label="kkk.text"
                  :value="kkk.id"
                />
              </el-select>
              <!-- radio -->
              <template v-if="kk.type===2">
                <el-radio-group v-model="registerForm.answers[kk.id]">
                  <el-radio
                    v-for="kkk of $t('radio')"
                    :key="kkk.value"
                    :label="kkk.value"
                  >{{ kkk.label }}</el-radio>
                </el-radio-group>
              </template>
              <!-- input -->
              <template v-if="kk.type===3">
                <el-input v-model="registerForm.answers[kk.id]" />
              </template>
            </el-form-item>
          </div>
        </template>
      </template>
      <!-- 遍历问答结束 -->
      <el-form-item prop="checkbox">
        <p v-for="(k,index) of registerForm.agreements" :key="k.id">
          <el-checkbox
            v-model="registerForm.agreements[index].result"
          >{{ registerForm.agreements[index].name }}</el-checkbox>
        </p>

        <p class="fx-tip-info">
          <i class="el-icon-info" />
          <span>
            <i18n path="tip.temp">
              <a slot="a" href="/#1" target="_blank">{{ $t('tip.a') }}</a>
            </i18n>
          </span>
        </p>
      </el-form-item>
      <el-form-item>
        <el-button
          type="primary"
          size="largn"
          :loading="registerLoading"
          class="submit"
          @click="submit"
        >{{ $t('submit') }}</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
import { email, phone } from '@/utils/regex';
import toTree from '@/utils/treeTotree';
import { judgeCountry, getAgreementList, regDetailed, getRegQuestionnaire, initRegDetailedr } from '@/api/register';
import lang from './lang';

export default {
  name: 'RegisterInfo',
  data() {
    const checkEmail = (rule, value, callback) => {
      if (!email.test(value)) {
        callback(new Error(this.$t('email.rule')));
      } else {
        callback();
      }
    };

    const checkTelephone = (rule, value, callback) => {
      if (!phone.test(value) || this.registerForm.phonecode === '') {
        callback(new Error(this.$t('telephone.rule')));
      } else {
        callback();
      }
    };

    return {
      registerLoading: false,
      countrySelect: [],
      currencySelect: [], // 货币类型
      accountTypeSelect: [], // 账户类型
      questionnaireList: [], // 问卷数据
      answersForm: {}, // 问卷表单
      hiddenForm: [], // 隐藏的表单
      identityOthersVisible: false, // 其他证件类型
      countryMarginBottom: 80,
      registerForm: {
        ln: this.$ln,
        answers: {},
        identityType: 1,
      },
      registerFormRules: {
        username: [
          {
            required: 'true',
            message: this.$t('email.required'),
            trigger: 'blur',
          },
          { validator: checkEmail, trigger: 'blur' },
        ],

        phone: [
          {
            required: 'true',
            message: this.$t('telephone.required'),
            trigger: 'blur',
          },
          { validator: checkTelephone, trigger: 'blur' },
        ],
        currency: [
          {
            required: true,
            message: this.$t('currency.rule'),
            trigger: 'change',
          },
        ],
        accountType: [
          {
            required: true,
            message: this.$t('accountType.rule'),
            trigger: 'change',
          },
        ],
        platform: [
          {
            required: true,
            message: this.$t('platform.rule'),
            trigger: 'change',
          },
        ],
        nationality: [
          {
            required: true,
            message: this.$t('nationality.rule'),
            trigger: 'change',
          },
        ],
        surName: [
          {
            required: true,
            message: this.$t('surName.rule'),
            trigger: 'blur',
          },
        ],
        lastName: [
          {
            required: true,
            message: this.$t('lastName.rule'),
            trigger: 'blur',
          },
        ],
        nickName: [
          {
            required: true,
            message: this.$t('nickName.rule'),
            trigger: 'blur',
          },
        ],
        identityType: [
          {
            required: true,
            message: this.$t('identityType.rule'),
            trigger: 'blur',
          },
        ],
        identity: [
          {
            required: true,
            message: this.$t('identity.rule'),
            trigger: 'blur',
          },
        ],

        birthday: [
          {
            required: true,
            message: this.$t('birthday.rule'),
            trigger: 'change',
          },
        ],
        city: [
          {
            required: true,
            message: this.$t('city.rule'),
            trigger: 'blur',
          },
        ],
        address: [
          {
            required: true,
            message: this.$t('address.rule'),
            trigger: 'blur',
          },
        ],
        addressEn: [
          {
            required: true,
            message: this.$t('addressEn.rule'),
            trigger: 'blur',
          },
        ],
        addressDate: [
          {
            required: true,
            message: this.$t('addressDate.rule'),
            trigger: 'blur',
          },
        ],
        homePhone: [
          {
            required: true,
            message: this.$t('homePhone.rule'),
            trigger: 'blur',
          },
        ],
      },
    };
  },
  i18n: {
    // `i18n` 选项，为组件设置语言环境信息
    messages: lang,
  },
  watch: {
    registerForm() {
      this.$forceUpdate();
    },
  },
  mounted() {
    const { utm_affiliatecode: agentcode, regtype } = this.$route.query;
    this.registerForm.agentcode = agentcode || this.registerForm.agentcode;
    this.registerForm.regtype = regtype || this.registerForm.regtype;
    this.initRequest();
  },

  methods: {
    // 获取城市和注册协议
    initRequest() {
      judgeCountry({ ln: this.$ln }).then((data) => {
        const {
          country: { code, phonecode },
          countrys,
        } = data;
        this.registerForm.country = code;
        this.registerForm.phonecode = phonecode;
        this.countrySelect = countrys;
      });

      // checkbox
      getAgreementList({
        orgid: 1,
        step: 2,
        ln: this.$ln,
      }).then((data) => {
        this.registerForm.agreements = data;
      });
      // 问答数据
      getRegQuestionnaire({
        ln: this.$ln,
      }).then((resp) => {
        const data = resp.map((k) => ({
          ...k,
          id: k.id.toString(),
          relationids: k.relationids && k.relationids.split(','),
        }));
        this.questionnaireList = toTree(data);
      });

      // 表单默认数据
      initRegDetailedr({ ln: this.$ln }).then((resp) => {
        const { birthcountry, country, currency, nationality, phone: mobile, phonecode, username } = resp.user;

        this.accountTypeSelect = resp.acctype.map((k) => ({
          label: k.typename,
          value: k.id,
          id: k.id,
        }));
        this.registerForm = {
          ...this.registerForm,
          birthcountry,
          country,
          currency,
          nationality,
          phone: mobile,
          phonecode,
          username,
        };
      });
    },
    sdf(data, id) {
      let resp = {};
      function res(arr) {
        arr.forEach((i) => {
          if (i.id === id) {
            resp = i;
            return;
          }
          if (i.children) {
            res(i.children);
          }
        });
      }
      res(data);
      return resp;
    },
    // 设置隐藏的表单
    handleHidden(value, id) {
      const data = this.sdf(this.questionnaireList, value);
      let { relationids } = data;
      relationids = JSON.parse(JSON.stringify(relationids));
      this.questionnaireList[id].children = this.questionnaireList[id].children.map((k) => {
        const flag = relationids.includes(k.id);
        return { ...k, hidden: flag };
      });
    },

    // 选择其他证件类型
    handleChange(value) {
      if (value === 9) {
        this.identityOthersVisible = true;
      } else {
        this.identityOthersVisible = false;
      }
    },

    submit() {
      let { birthday } = this.registerForm;
      const agreements = [];
      const answers = [];
      // eslint-disable-next-line no-restricted-syntax
      for (const k of this.registerForm.agreements) {
        agreements.push({ agreementid: k.id, result: k.result ? 1 : 0 });
        if (k.obligatory && !k.result) {
          // return;
        }
      }

      this.$refs.registerForm.validate((valid) => {
        if (valid) {
          Object.keys(this.registerForm.answers).forEach((k) => {
            const value = this.registerForm.answers[k];
            answers.push({ questionnaireid: k, result: value });
          });

          this.registerLoading = true;
          birthday = this.$moment(birthday).format('YYYY-MM-DD hh:mm:ss');
          const params = {
            ...this.registerForm,
            agreements,
            answers,
            birthday,
          };

          regDetailed(params)
            .then(() => {
              this.registerLoading = false;
              this.$message({
                type: 'success',
                message: this.$t('success'),
              });
              // this.$router.push('/register-info');
            })
            .catch(() => {
              this.registerLoading = false;
              this.$message({
                type: 'error',
                message: this.$t('fail'),
              });
            });
        }
      });
    },
  },
};
</script>
<style lang="scss">
.register-form {
  margin: 0 auto;
  max-width: 550px;
  p {
    margin: 0px 0px 10px;
    line-height: 1.6;
  }
  .tip-info {
  }
  .country .el-form-item__error {
    position: static;
  }
  .submit {
    width: 100%;
  }
  .el-select {
    width: 100%;
  }
  .el-form-item__label {
    line-height: 1.3;
    padding-top: 10px;
  }
}
.item-title {
  margin: 0px -50px 24px 0;
  padding: 50px 0px 10px 0;
  font-weight: bold;
  font-size: 1.1em;
  border-bottom: 1px solid #e2e2e2;
}
</style>
