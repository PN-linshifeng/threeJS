import step1 from '../step-1/lang';

export default {
  en: {
    ...step1.en,
  },
  'zh-cn': {
    ...step1['zh-cn'],
    currency: {
      label: '货币类型',
      rule: '请填写货币类型',
    },
    accountType: {
      label: '账户类型 ',
      rule: '请选择账户类型 ',
    },
    platform: {
      label: '交易平台 ',
      rule: '请选择交易平台',
    },
    nationality: {
      label: '国籍 ',
      rule: '请选择国籍',
    },
    title: {
      label: '称谓 ',
      select: [
        {
          label: '先生',
          value: 1,
        },
        {
          label: '女士',
          value: 3,
        },
      ],
    },
    surName: {
      label: '名(请填拼音)',
      rule: '请输入您证件上名字的拼音',
    },
    lastName: {
      label: '姓(请填拼音)',
      rule: '请输入您证件上姓氏的拼音',
    },
    nickName: {
      label: '中文名字',
      rule: '请输入中文名字',
    },
    identityType: {
      label: '证件类型',
      rule: '请选择证件类型',
      data: [
        {
          label: '身份证',
          value: 1,
        },
        {
          label: '护照',
          value: 2,
        },
        {
          label: '驾驶证',
          value: 3,
        },
        {
          label: '其他',
          value: 9,
        },
      ],
    },
    identityOthers: {
      rule: '请输入证件类型',
    },
    identity: {
      label: '证件号码',
      rule: '请输入真实有效的证件号码',
    },
    birthcountry: {
      label: '出生国家',
    },
    birthday: {
      label: '出生日期',
      rule: '请选择出生日期',
    },
    country: {
      label: '居住国家/地区',
    },
    city: {
      label: '城市',
      rule: '请输入城市',
    },
    address: {
      label: '住宅地址',
      rule: '请输入住宅地址',
    },
    addressEn: {
      label: '住宅地址（英文）',
      rule: '请输入住宅地址（英文）',
    },
    addressDate: {
      label: '居住年期',
      rule: '请输入整数',
    },
    homePhone: {
      label: '住宅电话号码',
      rule: '请输入住宅电话号码',
    },
    radio: [
      {
        label: '是',
        value: 1,
      },
      {
        label: '否',
        value: 0,
      },
    ],
  },
};
