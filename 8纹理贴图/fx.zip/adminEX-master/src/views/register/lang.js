export default {
  en: {
    email: {
      label: 'Emain',
      placeholder: 'This email address will be your username',
      required: 'Please enter a valid email address',
      rule:
        'This email address has been registered, please use another email address',
      ajax:
        'Please enter 10-15 characters containing English upper case letters, English lower case letters and westernized Arabic numerals ONLY',
    },
    password: {
      label: 'Password',
      placeholder: 'Please enter your password',
      required: 'Please enter letters and numbers',
      rule: 'At least 6 characters including letters and numbers',
    },
    password2: {
      label: 'Confirm password ',
      placeholder: 'Please confirm the password',
      required: 'Please confirm the password',
      rule: 'Please confirm the password',
    },
    telephone: {
      label: 'Telephone no.',
      placeholder: 'Please enter a correct mobile number',
      required: 'Please enter a correct mobile number',
      rule: 'Please enter a correct mobile number',
    },
    country: {
      label: 'Country/Region of Residence',
      placeholder: 'Please select and input your country of residence',
      required: 'Please select and input your country of residence',
      rule:
        'The products and services provide by MBG Markets are not available to residents of USA, Canada, New Zealand, Hong Kong or certain countries and jurisdictions outside of Australian, we also do not accept these source of fund. Governmental restrictions and our company policies prohibit us from opening accounts of the restricted United Nations Security Council (UNSC) and Department of Foreign Affairs and Trade (DFAT) sanctioned regimes, as well as other individuals or entities specially sanctioned.',
    },
    userType: 'User type',
    DA: 'Demo account',
    LA: 'Live account',
    IB: 'Introducing broker',
    MM: 'Money manager',
    others: 'Others',
    affiliate: 'Affiliate code/referral',
    tip: {
      a: 'some countries, regions and organisations',
      temp: 'We are temporarily unable to process applications from {0}',
    },
    submit: 'Submit',
  },
  'zh-cn': {
    email: {
      label: '电邮',
      placeholder: '该电邮将成为您的网站用户名',
      required: '请输入电邮',
      rule: '请输入真实有效的电邮',
      ajax: '该电邮已被注册，请使用其他电邮',
    },
    password: {
      label: '密码',
      placeholder: '请输入大小字母和数字',
      required: '请输入大小字母和数字',
      rule: '请输入10-15个字符，含且仅含英文大写字母、小写字母和数字',
    },
    password2: {
      label: '确认密码',
      placeholder: '请再次输入密码',
      required: '请再次输入密码',
      rule: '密码输入不一致，请重新输入',
    },
    telephone: {
      label: '手机号码',
      placeholder: '请输入电话号码',
      required: '请输入电话号码',
      rule: '请输入真实有效的电话号码',
    },
    country: {
      label: '居住国家/地区',
      placeholder: '请选择居住国家/地区',
      required: '请选择居住国家/地区',
      rule:
        'MBG Markets所提供的产品与服务尚未对美国、加拿大、新西兰、香港或少数非澳大利亚地区居民开放，亦无法接受来自这些国家或地区的存款。根据政府及本公司政策，MBG Markets不接受来自联合国安全理事会（UNSC）和澳大利亚外交贸易部（DFAT）颁布受管制国家居民以及个别受约束个人或组织之开户申请。',
    },
    userType: '注册类型',
    DA: '模拟账户',
    LA: '真实账号',
    IB: '介绍经纪商（IB）',
    MM: '介绍经纪商（IB）',
    others: '介绍经纪商（IB）',
    affiliate: '交易编码/介绍人',
    tip: {
      a: '国家、地区及组织列表',
      temp:
        '目前，MBG Markets暂时无法服务于来自某些国家、地区及组织的客户，具体信息请查看 {a}',
    },
    submit: '注册',
    success: '注册成功！',
    fail: '注册失败！',
  },
};
