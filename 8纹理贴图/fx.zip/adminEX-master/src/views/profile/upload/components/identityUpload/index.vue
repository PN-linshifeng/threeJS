<template>
  <el-dialog
    :visible="visible"
    :title="row.name"
    width="680px"
    :close-on-click-modal="false"
    :before-close="handleClose"
    @closed="handleClosed"
  >
    <el-form ref="form" :model="form" :data="form" :rules="formRules" label-width="100px">
      <el-form-item label="类型：" prop="doctypeid">
        <el-select v-model="form.doctypeid" @change="handleDocType">
          <el-option v-for="k of row.strIdList" :key="k.id" :value="k.id" :label="k.doctypename" />
        </el-select>
      </el-form-item>
      <el-form-item prop="docpath" label="正面：">
        <el-input v-model="form.docpath" class="hidden" />
        <el-upload
          class="avatar-uploader"
          :action="action"
          :show-file-list="false"
          :on-success="handleSuccess"
          :before-upload="beforeUpload"
          style="line-height:1"
        >
          <img v-if="docpath" :src="docpath" class="avatar" />
          <i v-else class="el-icon-plus avatar-uploader-icon" />
        </el-upload>
      </el-form-item>
      <el-form-item v-if="side" prop="docback" label="反面：">
        <el-input v-model="form.docback" class="hidden" />
        <el-upload
          class="avatar-uploader"
          :action="action"
          :show-file-list="false"
          :on-success="handleDocback"
          :before-upload="beforeUpload"
        >
          <img v-if="docback" :src="docback" class="avatar" />
          <i v-else class="el-icon-plus avatar-uploader-icon" />
        </el-upload>
      </el-form-item>
    </el-form>

    <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose">取 消</el-button>
      <el-button type="primary" :loading="submitLoading" @click="handleSubmit">确 定</el-button>
    </span>
  </el-dialog>
</template>
<script>
import uploadDocFile from '@/api/upload';

export default {
  props: {
    visible: { required: true, type: Boolean, default: false },
    submitLoading: { required: true, type: Boolean, default: false },
    row: {
      required: true,
      type: Object,
      default() {
        return {};
      },
    },
    docTypeList: {
      required: true,
      type: Array,
      default() {
        return [];
      },
    },
  },
  data() {
    return {
      action: uploadDocFile,
      side: false, // 正反面
      docpath: '', // 正面图片
      docback: '', // 反面图片
      form: {},
      formRules: {
        doctypeid: [{ required: true, message: '请选择类型', trigger: 'change' }],
        docback: [
          {
            required: true,
            message: '请上传证件反面',
            trigger: ['blur', 'change'],
          },
        ],
        docpath: [
          {
            required: true,
            message: '请上传证件正面',
            trigger: ['blur', 'change'],
          },
        ],
      },
    };
  },
  watch: {
    row() {
      if (this.$refs.form) {
        this.$refs.form.resetFields();
      }

      this.$set(this.form, 'typeid', this.row.id);
    },
  },

  methods: {
    // 关闭
    handleClose() {
      this.$emit('close');
    },
    handleClosed() {
      this.docpath = '';
      this.docback = '';
      this.side = false;
      this.$refs.form.resetFields();
    },
    // 确定
    handleSubmit() {
      this.$refs.form.validate(valid => {
        if (valid) {
          this.$emit('submit', this.form);
        }
      });
    },
    // 选择文档
    handleDocType(val) {
      const item = this.docTypeList.find(k => k.id === val);
      this.side = item;
    },
    // 上传正面成功
    handleSuccess(res, file) {
      if (res.code === 200) {
        this.$set(this.form, 'docpath', res.data.path);
        this.docpath = URL.createObjectURL(file.raw);
      }
    },
    // 上传反面成功
    handleDocback(res, file) {
      if (res.code === 200) {
        this.$set(this.form, 'docback', res.data.path);
        this.docback = URL.createObjectURL(file.raw);
      }
    },
    // 上传验证
    beforeUpload(file) {
      const isJPG = file.type === 'image/jpeg' || file.type === 'image/jpg' || file.type === 'image/png';
      const isLt2M = file.size / 1024 / 1024 < 2;

      if (!isJPG) {
        this.$message.error('上传头像图片只能是jpg,png格式!');
      }
      if (!isLt2M) {
        this.$message.error('上传头像图片大小不能超过 2MB!');
      }
      return isJPG && isLt2M;
    },
  },
};
</script>

<style lang="scss">
$size: 100px;
.avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: $size;
  height: $size;
  line-height: $size;
  text-align: center;
}
.avatar {
  width: $size;
  height: $size;
  display: block;
}
.el-input.hidden {
  display: none;
}
</style>
