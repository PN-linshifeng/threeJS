<template>
  <div class="app-container profile-upload">
    <!-- 身份证明 -->
    <div v-for="k of queryTypeList.data" :key="k.id" class="upload-item">
      <el-row class="header">
        <el-col :sm="12" class="required">
          <h3>{{ k.name }}</h3>
          <p v-if="k.remarks">{{ k.remarks }}</p>
        </el-col>
        <el-col :sm="12" class="text-right">
          <el-button icon="el-icon-upload2" type="danger" size="mini" @click="handleShow(k)">添加</el-button>
        </el-col>
      </el-row>
      <el-table :data="k.children" :show-header="true">
        <el-table-column label="图片" prop="docpath">
          <template slot-scope="scope">
            <img
              v-if="scope.row.docpath"
              :src="'/upload/showdoc?path='+scope.row.docpath"
              width="80"
            />
            <img
              v-if="scope.row.docback"
              :src="'/upload/showdoc?path='+scope.row.docback"
              width="80"
            />
          </template>
        </el-table-column>
        <el-table-column label="名称" prop="doctypeid">
          <template slot-scope="scope">{{ findDocType(scope.row.doctypeid) }}</template>
        </el-table-column>
        <el-table-column label="上传时间" prop="createtime" :formatter="formatTime" />
        <el-table-column label="审核时间" prop="updatetime" :formatter="formatTime" />
        <el-table-column label="操作" prop="name" class="fx-text-right">
          <template slot-scope>
            <div class="fx-text-right">
              <el-button icon="el-icon-upload2" type="primary" size="mini">修改</el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <identityDialog
      :visible="identityVisible"
      :submit-loading="submitLoading"
      :doc-type-list="docTypeList"
      :row="row"
      @close="handleClose"
      @submit="submit"
    />
  </div>
</template>
<script>
import toTree from '@/utils/treeTotree';
import { docType } from '@/api/systemType';
import { addUserDoc, querytDocList } from '@/api/profileUpload';
import identityDialog from './components/identityUpload/index';

export default {
  components: { identityDialog },
  data() {
    return {
      queryTypeList: {},

      // 添加身份证明参数
      docTypeList: [], // 文档类型
      identityVisible: false,
      submitLoading: false,
      row: {},
    };
  },
  mounted() {
    this.initData();
  },
  methods: {
    // 数据初始化
    initData() {
      docType({ ln: this.$ln }).then((data) => {
        this.docTypeList = data;
      });
      this.querytDocList();
    },
    // 列表查询
    querytDocList() {
      const params = { ln: this.$ln };
      querytDocList(params).then((data) => {
        const docList = data.doclist.data.map((k) => {
          const { id, ...items } = k;
          return { ...items, ID: id };
        });
        let treeData = [...data.typelist.data, ...docList];
        treeData = toTree(treeData, 'typeid');
        this.queryTypeList = { ...data.typelist.data, data: treeData };
      });
    },
    // 查找文档对应类型
    findDocType(id) {
      const item = this.docTypeList.find((k) => k.id === id);
      return item ? item.doctypename : id;
    },
    // 时间格式化
    formatTime(row, cell, val) {
      return this.$moment(val).format('YYYY-MM-DD hh:mm');
    },
    // 显示弹窗
    handleShow(row) {
      this.row = row;
      const strid = this.row.strid.split(',').map(Number);
      const data = this.docTypeList.filter((k) => strid.includes(k.id));
      this.row.strIdList = data;
      this.identityVisible = true;
    },
    /**
     * 以下是上传证明身份
     */
    // 关闭弹窗
    handleClose() {
      this.identityVisible = false;
    },
    // 提交
    submit(form) {
      // {"doctypeid":"1","docpath":"AD_1.jpg","front":"1","otherinfo":"","userid":""}
      let data = { doctypeid: '1', docpath: 'AD_1.jpg', front: '1', otherinfo: '' };
      data = Object.assign(data, form);
      this.submitLoading = true;
      addUserDoc(data)
        .then(() => {
          this.$message.success('上传成功');
          this.submitLoading = false;
          this.handleClose();
          this.querytDocList();
        })
        .catch(() => {
          this.submitLoading = false;
        });
    },
  },
};
</script>
<style lang="scss">
.upload-item {
  margin-bottom: 24px;
  .header {
    background: #f5f5f5;
    padding: 10px;
    display: flex;
    align-items: center;
    .required {
      padding-left: 12px;
      &::before {
        display: block;
        content: '*';
        float: left;
        margin-left: -12px;
        line-height: 35px;
        color: red;
        font-size: 20px;
      }
    }
    h3,
    p {
      margin: 5px 0;
    }
    h3 {
      font-size: 1.1em;
    }
    p {
      font-size: 12px;
      color: #999999;
    }
  }
}
</style>
