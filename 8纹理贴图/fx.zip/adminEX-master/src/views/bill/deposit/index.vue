<template>
  <div class="app-container">
    <el-row>
      <el-col>
        <el-form
          ref="form"
          :model="form"
          :rules="formRules"
          label-width="120px"
          class="form"
          @submit.native.prevent="formSubmit"
        >
          <el-form-item label="入金金额：" prop="amount">
            <el-input v-model="form.amount" placeholder="金额" />
          </el-form-item>
          <el-form-item label="MT账户：" prop="mt_login">
            <el-select v-model="form.mt_login">
              <el-option v-for="k of MTSelect" :key="k.value" :label="k.label" :value="k.value" />
            </el-select>
          </el-form-item>
          <el-form-item label="入金方式：" prop="gatewayid">
            <el-select v-model="form.gatewayid">
              <el-option
                v-for="k of gatewayidSelect"
                :key="k.value"
                :label="k.label"
                :value="k.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item class="action">
            <el-button type="primary" native-type="submit" :loading="submitLoading">马上入金</el-button>
          </el-form-item>
        </el-form>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import { amount } from '@/utils/regex';
import { getDeposit, deposit } from '@/api/bill';

export default {
  data() {
    return {
      submitLoading: false,
      form: {
        amount: '',
        gatewayid: 101,
        mt_login: 0,
        ln: this.$ln,
      },
      formRules: {
        amount: [
          { required: true, message: '请输入入金金额', trigger: ['blur', 'change'] },
          { pattern: amount, trigger: ['blur', 'change'], message: '格式错误' },
        ],
        mt_login: [{ required: true, message: '请选择MT账户', trigger: ['change'] }],
      },
      MTSelect: [{ label: '新账号激活', value: 0 }],
      gatewayidSelect: [
        { label: '支付宝', value: 100 },
        { label: '银行卡', value: 101 },
      ],
    };
  },
  mounted() {
    this.initData();
  },
  methods: {
    // 初始化接口
    initData() {
      // 初始化MT4列表
      getDeposit().then((data) => {
        if (data.mt_logins) {
          const ids = data.mt_logins.split(',');
          const [mtLogin] = ids; // 默认选择
          this.MTSelect = ids.map((k) => ({ label: k, value: k }));
          this.form.mt_login = mtLogin;
        }
      });
    },
    // 提交数据
    formSubmit() {
      this.$refs.form.validate(async (valid) => {
        if (valid) {
          this.submitLoading = true;
          try {
            await deposit(this.form);
            this.$message.success('入金成功！');
          } catch (err) {
            this.$message.error('入金失败！');
          } finally {
            this.submitLoading = false;
          }
        }
      });
    },
  },
};
</script>
<style lang="scss" scoped>
.form {
  margin: 50px auto;
  max-width: 560px;
  .action {
    margin-top: 50px;
  }
}
</style>
