<template>
  <div class="app-container">
    <el-row style="margin-bottom:20px">
      <el-col>
        <el-table
          v-loading="queryListLoading"
          :data="dataList.data"
          style="width: 100%;margin-bottom: 20px;"
          row-key="id"
        >
          <el-table-column prop="username" label="用户名" />
          <el-table-column prop="nickname" label="昵称" />
          <el-table-column prop="typename" label="类型" />
          <el-table-column prop="doctypename" label="文档类型" />

          <el-table-column prop="updatetime" label="更新时间" :formatter="time" />
          <el-table-column label="操作" :width="270">
            <template slot-scope>
              <el-button type="primary" size="small" icon="el-icon-edit">修改</el-button>
              <el-button type="danger" size="small" icon="el-icon-delete">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <el-pagination
          background
          layout="prev, pager, next"
          :page-count="dataList.pageTotal"
          :current-page.sync="dataList.pageNum"
          class="fx-text-right"
          @current-change="pageChange"
        />
      </el-col>
    </el-row>
  </div>
</template>
<script>
import queryList from '@/api/audit';

export default {
  name: 'Document',
  components: {},
  data() {
    return {
      // loading 参数
      queryListLoading: false,
      dataList: {},
      searchForm: {
        ln: this.$ln,
        pageNum: 1,
        pageSize: 10,
        orderBy: 'createtime',
        sort: 'desc',
      },
    };
  },

  computed: {},

  created() {
    this.queryList();
  },
  methods: {
    queryList() {
      this.queryListLoading = true;
      queryList(this.searchForm)
        .then((resp) => {
          this.dataList = resp;
          this.queryListLoading = false;
        })
        .catch(() => {
          this.queryListLoading = false;
        });
    },
    // 分页
    pageChange(page) {
      this.searchForm.pageNum = page;
      this.queryList();
    },

    // 时间格式化
    time(row, column, cellValue) {
      return this.$moment(cellValue).format('YYYY-MM-DD');
    },

    // 添加活动
    addEditFormShow() {},
  },
};
</script>
