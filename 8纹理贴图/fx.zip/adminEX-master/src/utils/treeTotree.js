/* eslint-disable no-restricted-syntax */
/* eslint-disable no-return-assign */
/* eslint-disable no-continue */
/* eslint-disable no-sequences */
function convert(list, pid = 'pid') {
  const res = [];
  const map = list.reduce((re, v) => ((re[v.id] = v), re), {});
  for (const item of list) {
    if (item[pid] === 0 || !item[pid]) {
      res.push(item);
      continue;
    }
    if (item[pid] in map) {
      const parent = map[item[pid]];
      // parent.hasChildren = true;
      parent.children = parent.children || [];
      parent.children.push(item);
    }
  }
  return res;
}

export default convert;
