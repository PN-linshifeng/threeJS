/* eslint-disable no-console */
/* eslint-disable comma-dangle */
import axios from 'axios';
import qs from 'qs';
import { MessageBox, Message } from 'element-ui';
import store from '@/store';
import router from '@/router';
// import { getToken } from '@/utils/auth';

// create an axios instance
const service = axios.create({
  baseURL: process.env.VUE_APP_BASE_API, // url = base url + request url
  // withCredentials: true, // send cookies when cross-domain requests
  timeout: 10000, // request timeout
  // 'Content-Type': 'application/x-www-form-urlencoded',
  // 'Content-Type': 'application/json',
});

/**
 * @数字转为字符串
 * @param {Object} data
 * @returns {Object} newObj
 */
const objFormat = function objFormat(data) {
  const isObj = function isObj(obj) {
    return (
      Object.prototype.toString.call(obj) === '[object Object]' ||
      Object.prototype.toString.call(obj) === '[object Array]'
    );
  };
  const numberToString = function isNumber(obj) {
    return Object.prototype.toString.call(obj) === '[object Number]' ? obj.toString() : obj;
  };
  if (!isObj(data)) {
    return data;
  }
  const newObj = Array.isArray(data) ? [...data] : { ...data };

  Reflect.ownKeys(newObj).forEach(k => {
    newObj[k] = isObj(newObj[k]) ? objFormat(newObj[k]) : numberToString(newObj[k]);
  });
  return newObj;
};

// request interceptor
service.interceptors.request.use(
  config => {
    // post 提交的params变成string
    if (config.method === 'post' && config.data) {
      const {
        data: { params },
      } = config;
      if (params && Object.prototype.toString.call(params) === '[object Object]') {
        config.data.params = JSON.stringify(objFormat(params));
      }
      // config.headers['Content-Type'] = 'application/x-www-form-urlencode';
      config.data = qs.stringify(config.data);
    }

    return config;
  },
  error => {
    console.log(error); // for debug
    return Promise.reject(error);
  }
);

// response interceptor
service.interceptors.response.use(
  /**
   * If you want to get http information such as headers or status
   * Please return  response => response
   */

  /**
   * Determine the request status by custom code
   * Here is just an example
   * You can also judge the status by HTTP Status Code
   */
  async response => {
    const res = response.data;
    // if the custom code is not 20000, it is judged as an error.
    if (res.code !== 200) {
      if (res.code === 501) {
        await store.dispatch('user/resetToken');
        router.push(`/admin/login?redirect=${window.location.pathname}`);
      }
      Message({
        message: res.message || 'Error',
        type: 'error',
        duration: 5 * 1000,
      });

      // 50008: Illegal token; 50012: Other clients logged in; 50014: Token expired;
      if (res.code === 50008 || res.code === 50012 || res.code === 50014) {
        // to re-login
        MessageBox.confirm(
          'You have been logged out, you can cancel to stay on this page, or log in again',
          'Confirm logout',
          {
            confirmButtonText: 'Re-Login',
            cancelButtonText: 'Cancel',
            type: 'warning',
          }
        ).then(() => {
          store.dispatch('user/resetToken').then(() => {
            window.location.reload();
          });
        });
      }

      return Promise.reject(res.message || 'Error');
    }
    return res.data;
  },
  async error => {
    // eslint-disable-next-line no-console
    console.error(`${error}`); // for debug
    const { status = '', data = {} } = error.response || {};
    const { message } = data;

    Message({
      message: message || error,
      type: 'error',
      duration: 5 * 1000,
    });
    if (status === 501) {
      await store.dispatch('user/resetToken');
      router.push(`/admin/login?redirect=${window.location.pathname}`);
    }
    return Promise.reject(error);
  }
);

export default service;
