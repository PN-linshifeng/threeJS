/**
 * 类型管理
 */
export const systemType = new Map([
  [1, 'account'],
  [2, 'document'],
  [3, 'data'],
  [4, 'mail'],
]);

/**
 * 客户类型
 */
export const clientType = new Map([
  [1, 'client'],
  [2, 'ib'],
  [3, 'employee'],
]);
