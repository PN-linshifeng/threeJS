/* eslint-disable no-useless-escape */

export const email = /^([a-zA-Z0-9]+[_|\-|\.]*)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\-|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,6}$/; // 邮件
export const password = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[a-zA-Z0-9]{10,15}$/; // 密码
export const cnname = /^[\u4e00-\u9fa5]*$/; // 中文名字
export const name = /^[a-zA-Z\s]{1,30}$/; // 英文名字
export const phone = /^\+?[0-9-()\s]{0,50}$/; // 电话
export const mobile = /^1(3|4|5|7|8)\d{9}$/; // 手机
export const city = /^[a-zA-Z\s\u4e00-\u9fa5]*$/; // 城市
export const address = /^[a-zA-Z0-9\s\u4e00-\u9fa5]+$/; // 地址
export const zipcode = /^[a-zA-Z0-9]*$/; // 邮编
export const amount = /(^[1-9]([0-9]+)?(\.[0-9]{1,2})?$)|(^(0){1}$)|(^[0-9]\.[0-9]([0-9])?$)/; // 金额
