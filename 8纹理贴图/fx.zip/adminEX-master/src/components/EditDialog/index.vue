<template>
  <el-dialog
    :visible.sync="visible"
    :title="title"
    :width="width"
    :before-close="handleClose"
    :close-on-click-modal="false"
  >
    <slot />
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose">取 消</el-button>
      <el-button type="primary" :loading="submitLoading" @click="handleSubmit">确 定</el-button>
    </span>
  </el-dialog>
</template>
<script>
export default {
  name: 'EditDialog',
  props: {
    visible: { required: true, default: false, type: Boolean },
    width: { required: false, default: '680px', type: String },
    title: { required: false, default: '', type: String },
    submitLoading: { required: false, default: false, type: Boolean },
  },
  methods: {
    handleClose() {
      this.$emit('close');
    },
    handleSubmit() {
      this.$emit('submit');
    },
  },
};
</script>
